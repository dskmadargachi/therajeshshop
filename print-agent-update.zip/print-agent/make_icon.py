#!/usr/bin/env python3
"""Generates assets/printer.ico (purple rounded-square + white printer, same look as therajesh.shop).
Run:  py make_icon.py      (needs: pip install pillow).  BUILD_EXE.bat runs it automatically when the .ico is missing."""
import os, sys
from PIL import Image, ImageDraw

SIZES = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
C1, C2 = (0x7C, 0x3A, 0xED), (0x63, 0x66, 0xF1)          # #7C3AED -> #6366F1
S = 1024                                                  # draw big, shrink = smooth edges at every size


def master():
    # diagonal gradient (top-left purple -> bottom-right indigo)
    grad = Image.new("RGB", (S, S))
    px = grad.load()
    for y in range(S):
        for x in range(S):
            t = (x + y) / (2 * (S - 1))
            px[x, y] = tuple(int(C1[i] + (C2[i] - C1[i]) * t) for i in range(3))
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, S - 1, S - 1), radius=int(S * 0.225), fill=255)
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    img.paste(grad, (0, 0), mask)

    d = ImageDraw.Draw(img)
    W = (255, 255, 255, 255)
    P = (0x6D, 0x4A, 0xEA, 255)                           # purple "ink" used for the details cut into the white shapes
    u = S / 100.0
    r = lambda x0, y0, x1, y1: (x0 * u, y0 * u, x1 * u, y1 * u)
    d.rounded_rectangle(r(30, 19, 70, 40), radius=3 * u, fill=W)              # paper going in (top)
    d.rounded_rectangle(r(16, 36, 84, 68), radius=9 * u, fill=W)              # printer body
    d.rounded_rectangle(r(30, 56, 70, 83), radius=3 * u, fill=W, outline=P, width=int(2.4 * u))   # paper coming out
    d.line(r(37, 65, 63, 65), fill=P, width=int(2.4 * u))
    d.line(r(37, 72, 58, 72), fill=P, width=int(2.4 * u))
    d.ellipse(r(70, 44, 77, 51), fill=P)                                     # status dot
    return img


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    out = os.path.join(here, "assets")
    os.makedirs(out, exist_ok=True)
    m = master()
    ico = os.path.join(out, "printer.ico")
    m.resize((256, 256), Image.LANCZOS).save(ico, format="ICO", sizes=SIZES)
    m.resize((256, 256), Image.LANCZOS).save(os.path.join(out, "printer.png"))
    print("Created", ico, [s[0] for s in SIZES])


if __name__ == "__main__":
    sys.exit(main())
