// Tells Puppeteer (used by whatsapp-web.js) not to download its own Chrome: the PC's installed Chrome/Edge is used instead.
module.exports = { skipDownload: true };
