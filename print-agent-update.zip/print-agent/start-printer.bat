@echo off
title Digital Seva Kendra - WhatsApp Bot + Auto Printer
cd /d "%~dp0"
set PUPPETEER_SKIP_DOWNLOAD=true
echo.
echo  === Digital Seva Kendra : WhatsApp Bot + Auto Printer ===
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Opening the download page - install the LTS version, then double-click this file again.
  start https://nodejs.org/en/download
  pause
  exit /b 1
)
if not exist config.env (
  copy config.env.example config.env >nul
  echo First time setup: config.env was created. Set AGENT_KEY ^(and PRINTER_NAME if needed^), save, close Notepad.
  notepad config.env
)
if not exist .installed (
  echo First run: installing required parts. This takes a few minutes, please wait...
  call npm install
  if errorlevel 1 (
    echo Install failed. Delete the node_modules folder, check the internet connection and try again.
    pause
    exit /b 1
  )
  echo ok> .installed
)
:loop
node local-print-server.js
echo.
echo Agent stopped. Restarting in 5 seconds... ^(close this window to quit^)
timeout /t 5 /nobreak >nul
goto loop
