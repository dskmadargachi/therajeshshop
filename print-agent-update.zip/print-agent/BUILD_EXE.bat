@echo off
cd /d "%~dp0"
title Building Agent
echo.
echo  ===== Agent - build .exe =====
echo.
where py >nul 2>nul || ( echo  Python is not installed. Install it from python.org ^(tick "Add python.exe to PATH"^), then run this again. & pause & exit /b 1 )
if not exist printer_agent_gui.py ( echo  printer_agent_gui.py is missing in this folder. & pause & exit /b 1 )
if not exist SumatraPDF.exe (
  echo  SumatraPDF.exe is missing in this folder.
  echo  Download the PORTABLE version from sumatrapdfreader.org, rename it to SumatraPDF.exe,
  echo  put it next to this file, then run this again.
  pause & exit /b 1
)
echo [1/4] Installing builder ^(internet needed the first time^)...
py -m pip install --upgrade pip pyinstaller pywebview pystray pillow
if errorlevel 1 ( echo  Could not install the builder. Check the internet and try again. & pause & exit /b 1 )
echo.
if not exist assets\printer.ico (
  echo  Creating the purple printer icon ^(assets\printer.ico^)...
  py make_icon.py
  if errorlevel 1 ( echo  Could not create the icon. & pause & exit /b 1 )
)
echo [2/4] Closing the old agent if it is running...
taskkill /f /im RajeshPrintAgent.exe >nul 2>nul
echo.
echo [3/4] Building RajeshPrintAgent.exe ...
py -m PyInstaller --noconfirm --clean --onefile --windowed --name RajeshPrintAgent --collect-all webview --hidden-import pystray._win32 --icon "assets\printer.ico" --add-data "assets\printer.ico;assets" --add-data "passport_sheet.py;." --hidden-import passport_sheet --hidden-import PIL.ImageDraw --hidden-import PIL.ImageOps --add-binary "SumatraPDF.exe;." printer_agent_gui.py
if not exist dist\RajeshPrintAgent.exe ( echo. & echo  Build failed - send a photo of this window. & pause & exit /b 1 )
copy /y dist\RajeshPrintAgent.exe RajeshPrintAgent.exe >nul
echo.
echo [4/4] Turning on "start with Windows"...
RajeshPrintAgent.exe --install-startup
if exist local-print-server.js if not exist node_modules (
  echo  WhatsApp bot: one-time setup needed - run INSTALL_WHATSAPP.bat once ^(needs Node.js^).
)
echo.
echo  DONE!  RajeshPrintAgent.exe is in this folder.
echo  - It starts by itself every time this PC starts ^(minimised^).
echo  - Double-click it now to open it. Enter your Agent key in Settings the first time.
echo.
choice /c YN /m "Open it now"
if errorlevel 2 exit /b 0
start "" RajeshPrintAgent.exe
