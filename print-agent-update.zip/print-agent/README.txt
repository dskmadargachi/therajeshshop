RAJESH PRINT AGENT  -  now with the WhatsApp bot, UPI QR payments and cash approval
==================================================================================

ONE APP DOES EVERYTHING (printer_agent_gui.py  ->  RajeshPrintAgent.exe)
  Tab "Live Queue"       website + WhatsApp + counter jobs, payment badges, Approve & Print / Preview / Reprint / Cancel,
                         green "Cash Received - Print Now" for cash orders, today's UPI / cash / pages.
  Tab "WhatsApp"         starts local-print-server.js as a hidden background process, shows the pairing QR,
                         "Connected: +91...", Reconnect / Logout / Start / Stop.
  Tab "Printers & Rules" B&W printer, Color printer, Photo, A3, paper size + tray, Auto-Print rule, bot mode, keep files, sound.
  Tab "Counter"          the normal counter.html inside the window.
  Light / dark theme button and sound button are in the top bar. Closing the window (X) only hides it in the Windows system tray (near the clock) - printing and the bot keep running. Quit fully: right-click the tray icon > Quit Agent Completely. Auto-startup with Windows is ON by default (Settings toggle).

THE TWO PRINT RULES
  - Auto-Print Online Paid Orders (UPI/Razorpay) ON  -> printed the moment the payment is confirmed.
  - Cash orders NEVER auto-print. They wait for "Cash Received - Print Now" (here or in counter.html).

FILES THAT MUST SIT TOGETHER (same folder as RajeshPrintAgent.exe, next to SumatraPDF.exe)
  printer_agent_gui.py, local-print-server.js, package.json, .puppeteerrc.cjs,
  BUILD_EXE.bat, INSTALL_WHATSAPP.bat, START_PRINT_AGENT.bat, RajeshPrintAgent.spec

FIRST-TIME SETUP (shop PC, Windows)
  1. Deploy the new site (_worker.js, counter.html, index.html ...) to Cloudflare FIRST, with the variables from SETUP.md.
  2. Install Node.js LTS from nodejs.org (only needed for the WhatsApp bot). Google Chrome or Microsoft Edge must be installed.
  3. Double-click INSTALL_WHATSAPP.bat once (a few minutes, internet needed). It also works from the app: WhatsApp tab > "Install WhatsApp parts".
  4. Double-click BUILD_EXE.bat to build RajeshPrintAgent.exe (or START_PRINT_AGENT.bat to run it from Python).
  5. Open the app > Settings > Website + Agent key (= AGENT_KEY in Cloudflare) > Save.
  6. WhatsApp tab > scan the QR with the shop phone: WhatsApp > Linked devices > Link a device.

IF SOMETHING IS WRONG
  - WhatsApp tab says "Node.js is not installed"   -> install Node.js LTS, reopen the app.
  - "WhatsApp parts are not installed yet"         -> press the Install button / run INSTALL_WHATSAPP.bat.
  - npm install fails on "chrome"                  -> delete the node_modules folder and %USERPROFILE%\.cache\puppeteer, run INSTALL_WHATSAPP.bat again.
  - Bot keeps stopping                             -> read the Bot log on the WhatsApp tab.
  - Old agent gets 401                             -> the site must be deployed first and the Agent key must equal AGENT_KEY.
  - No window / WebView2 error                     -> install "Microsoft Edge WebView2 Runtime"; the old classic window opens meanwhile.

NOTE: whatsapp-web.js is an unofficial WhatsApp connection. Use a dedicated shop number; WhatsApp can restrict numbers that use it.
