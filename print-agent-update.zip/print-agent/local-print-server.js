'use strict';
/*
 * Digital Seva Kendra – Local Windows Print Agent
 *  Run with  --wa-only  when the Python Print Agent (RajeshPrintAgent) does the printing: this script then ONLY runs the
 *  WhatsApp bot (QR pairing, menu, payment QR cards) and reports its status to the Python app on stdout (@@WA {...}).
 *  1) WhatsApp bridge (whatsapp-web.js): scan a QR once, customers send files to the shop's WhatsApp
 *  2) Polls https://therajesh.shop/api/agent/jobs for approved jobs (website AND WhatsApp orders)
 *  3) Silent printing: images -> clean A4 PDF (pdf-lib), then SumatraPDF / pdf-to-printer with Color|B&W, paper, copies
 *  4) Marks jobs Printed on the counter and wipes temp files
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');

// ---------------------------------------------------------------- config (config.env)
function loadEnvFile(file) {
  const out = {};
  try {
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
      if (m && !line.trim().startsWith('#')) out[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  } catch {}
  return out;
}
const E = { ...loadEnvFile(path.join(__dirname, 'config.env')), ...process.env };
const CFG = {
  site: (E.SITE_URL || 'https://therajesh.shop').replace(/\/+$/, ''),
  key: (E.AGENT_KEY || '').trim(),
  printer: (E.PRINTER_NAME || '').trim(),                 // empty = Windows default printer
  whatsapp: !/^(off|0|no|false)$/i.test(E.WHATSAPP || 'on'),
  poll: Math.max(2, Number(E.POLL_SECONDS) || 3) * 1000,
  paper4x6: (E.PAPER_4X6 || 'A6').trim(),                 // SumatraPDF has no "4x6" name; A6 is the closest standard size
  sumatra: (E.SUMATRA_PATH || '').trim(),
  soffice: (E.SOFFICE_PATH || '').trim(),
  chrome: (E.CHROME_PATH || '').trim(),
};
// Uses the Chrome or Edge already installed on the PC (no separate browser download needed)
function findBrowser() {           // CHROME_PATH first; when it is empty/wrong: auto-detect chrome.exe / msedge.exe
  const la = process.env.LOCALAPPDATA || '', pf = process.env.ProgramFiles || 'C:\\Program Files', pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const list = [CFG.chrome,
    path.join(pf, 'Google\\Chrome\\Application\\chrome.exe'), path.join(pf86, 'Google\\Chrome\\Application\\chrome.exe'), path.join(la, 'Google\\Chrome\\Application\\chrome.exe'),
    path.join(pf86, 'Microsoft\\Edge\\Application\\msedge.exe'), path.join(pf, 'Microsoft\\Edge\\Application\\msedge.exe'), path.join(la, 'Microsoft\\Edge\\Application\\msedge.exe'),
    '/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser'].filter(Boolean);
  return list.find((p) => fs.existsSync(p)) || '';
}
// ---- the PC's installed Chrome / Edge is only ever EXECUTED (read-only). Nothing in or around its folders is deleted or changed. ----
const SESSION_ROOT = path.join(__dirname, '.wa-session');          // the bot's own, isolated browser profile (inside the print-agent folder)
const PROTECTED = [/google[\\/]chrome/i, /[\\/]chrome[\\/]user data/i, /microsoft[\\/]edge/i, /[\\/]edge[\\/]user data/i, /\.config[\\/](google-chrome|chromium)/i];
const isProtected = (p) => PROTECTED.some((r) => r.test(path.resolve(p)));
const isInside = (p, root) => { const r = path.relative(path.resolve(root), path.resolve(p)); return !!r && !r.startsWith('..') && !path.isAbsolute(r); };
// the only recursive deletes in this program: our own temp folder / one order's temp folder
function safeRmTemp(p) { if (isProtected(p) || !(p === TMP_ROOT || isInside(p, TMP_ROOT))) return; try { fs.rmSync(p, { recursive: true, force: true }); } catch {} }
// Chromium leaves these behind after a crash / kill; with them present the profile looks "in use" (userDataDir error).
// ONLY these three files, ONLY inside <print-agent>\.wa-session.
function clearChromeLocks() {
  if (isProtected(SESSION_ROOT)) return;
  let dirs = [];
  try { dirs = fs.readdirSync(SESSION_ROOT).map((d) => path.join(SESSION_ROOT, d)); } catch { return; }
  for (const d of [SESSION_ROOT, ...dirs]) for (const n of ['SingletonLock', 'SingletonSocket', 'SingletonCookie']) {
    const f = path.join(d, n);
    if (isInside(f, SESSION_ROOT) && !isProtected(f)) { try { fs.rmSync(f, { force: true }); } catch {} }
  }
}
// Puppeteer's own bundled Chromium (if it was downloaded) is preferred; otherwise the PC's chrome.exe / msedge.exe is started read-only
function bundledChromium() { try { const p = require('puppeteer').executablePath(); return p && fs.existsSync(p) ? p : ''; } catch { return ''; } }
function browserToUse() { return bundledChromium() || findBrowser(); }
const LAUNCH_TIMEOUT = 60000;       // browser / WhatsApp Web start-up (was 30 s)
const WA_ONLY = process.argv.includes('--wa-only') || /^(0|off|no|false)$/i.test(E.PRINT_JOBS || '');
const emit = (o) => { try { console.log('@@WA ' + JSON.stringify(o)); } catch {} };   // machine-readable line for printer_agent_gui.py
const TMP_ROOT = path.join(os.tmpdir(), 'seva-print');
const log = (...a) => console.log(new Date().toLocaleTimeString('en-IN', { hour12: false }), ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
process.on('unhandledRejection', (e) => log('⚠️  unhandled:', (e && e.message) || e));
process.on('uncaughtException', (e) => log('⚠️  error:', (e && e.message) || e));

// ---------------------------------------------------------------- website API
async function api(method, p, opt = {}) {
  const headers = { 'x-agent-key': CFG.key, ...(opt.json ? { 'content-type': 'application/json' } : {}) };
  const r = await fetch(`${CFG.site}/api/${p}`, { method, headers, body: opt.json ? JSON.stringify(opt.json) : opt.form, signal: AbortSignal.timeout(opt.timeout || 30000) });
  if (r.status === 401) throw new Error('Website rejected the AGENT_KEY – check config.env');
  return r;
}

// ---------------------------------------------------------------- file type helpers
function sniff(buf) {
  if (buf.slice(0, 4).toString() === '%PDF') return 'pdf';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'jpg';
  if (buf.slice(1, 4).toString() === 'PNG') return 'png';
  if (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'webp';
  return null;
}
function jpegOrientation(buf) {          // EXIF orientation so phone photos are not printed sideways
  try {
    let i = 2;
    while (i < buf.length - 4) {
      if (buf[i] !== 0xff) break;
      const marker = buf[i + 1], len = buf.readUInt16BE(i + 2);
      if (marker === 0xe1 && buf.slice(i + 4, i + 8).toString() === 'Exif') {
        const t = i + 10, le = buf.slice(t, t + 2).toString() === 'II';
        const u16 = (o) => (le ? buf.readUInt16LE(t + o) : buf.readUInt16BE(t + o));
        const u32 = (o) => (le ? buf.readUInt32LE(t + o) : buf.readUInt32BE(t + o));
        const ifd = u32(4), n = u16(ifd);
        for (let k = 0; k < n; k++) if (u16(ifd + 2 + k * 12) === 0x0112) return u16(ifd + 2 + k * 12 + 8);
        return 1;
      }
      i += 2 + len;
    }
  } catch {}
  return 1;
}
const PAGE = { A4: [595.28, 841.89], A3: [841.89, 1190.55], '4x6': [288, 432] };

// ---------------------------------------------------------------- image -> PDF (fits the page, never cropped)
async function imagesToPdf(images, paper) {
  const { PDFDocument, degrees } = require('pdf-lib');
  const pdf = await PDFDocument.create();
  for (const buf of images) {
    const kind = sniff(buf);
    const img = kind === 'png' ? await pdf.embedPng(buf) : await pdf.embedJpg(buf);
    const o = kind === 'jpg' ? jpegOrientation(buf) : 1;
    const turn = { 3: 180, 4: 180, 5: 90, 6: 90, 7: 270, 8: 270 }[o] || 0;           // clockwise degrees needed to look upright
    const sideways = turn === 90 || turn === 270;
    const ew = sideways ? img.height : img.width, eh = sideways ? img.width : img.height;   // size as it will look
    let [pw, ph] = PAGE[paper] || PAGE.A4;
    if (ew > eh) [pw, ph] = [ph, pw];                                                       // landscape photo -> landscape page
    const m = paper === '4x6' ? 0 : 18;
    const k = Math.min((pw - 2 * m) / ew, (ph - 2 * m) / eh);
    const bw = ew * k, bh = eh * k, bx = (pw - bw) / 2, by = (ph - bh) / 2;
    const page = pdf.addPage([pw, ph]);
    const iw = img.width * k, ih = img.height * k;       // un-rotated size on paper
    if (turn === 0) page.drawImage(img, { x: bx, y: by, width: iw, height: ih });
    else if (turn === 90) page.drawImage(img, { x: bx, y: by + bh, width: iw, height: ih, rotate: degrees(-90) });
    else if (turn === 270) page.drawImage(img, { x: bx + bw, y: by, width: iw, height: ih, rotate: degrees(90) });
    else page.drawImage(img, { x: bx + bw, y: by + bh, width: iw, height: ih, rotate: degrees(180) });
  }
  return Buffer.from(await pdf.save());
}
async function pdfPageCount(buf) {
  const { PDFDocument } = require('pdf-lib');
  return (await PDFDocument.load(buf, { ignoreEncryption: true })).getPageCount();
}

// ---------------------------------------------------------------- Word / Excel / PowerPoint (needs LibreOffice)
function findSoffice() {
  const c = [CFG.soffice, 'C:\\Program Files\\LibreOffice\\program\\soffice.exe', 'C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe', '/usr/bin/soffice'].filter(Boolean);
  return c.find((p) => fs.existsSync(p));
}
function officeToPdf(file, outDir) {
  return new Promise((resolve, reject) => {
    const exe = findSoffice();
    if (!exe) return reject(new Error('Word/Excel/PowerPoint files need LibreOffice on the shop PC (free) – or ask the customer for a PDF'));
    execFile(exe, ['--headless', '--convert-to', 'pdf', '--outdir', outDir, file], { timeout: 120000 }, (err) => {
      const out = path.join(outDir, path.basename(file).replace(/\.[^.]+$/, '') + '.pdf');
      if (err || !fs.existsSync(out)) return reject(new Error('Could not convert the document to PDF'));
      resolve(out);
    });
  });
}

// ---------------------------------------------------------------- silent printing
function findSumatra() {
  const cands = [CFG.sumatra, path.join(__dirname, 'SumatraPDF.exe')];
  try {
    const dir = path.join(path.dirname(require.resolve('pdf-to-printer')), '..', 'dist');
    for (const d of [dir, path.dirname(require.resolve('pdf-to-printer'))]) if (fs.existsSync(d)) for (const f of fs.readdirSync(d)) if (/^SumatraPDF.*\.exe$/i.test(f)) cands.push(path.join(d, f));
  } catch {}
  return cands.filter(Boolean).find((p) => fs.existsSync(p));
}
async function printPdf(file, { color, paper, copies }) {
  const paperName = paper === '4x6' ? CFG.paper4x6 : paper === 'A3' ? 'A3' : 'A4';
  const exe = findSumatra();
  // COPIES_MODE=loop (default): N separate 1-copy jobs = exactly N prints even when the driver ignores the copies setting (Canon G-series)
  // COPIES_MODE=driver: ONE job with SumatraPDF's "Nx" setting
  const n = Math.max(1, copies), loop = (String(E.COPIES_MODE || 'loop').trim().toLowerCase() !== 'driver') && n > 1;
  const jobs = loop ? n : 1, perJob = loop ? 1 : n;
  if (exe) {            // exact flags:  color|monochrome, paper=, fit, Nx copies
    const settings = [color ? 'color' : 'monochrome', `paper=${paperName}`, 'fit', ...(perJob > 1 ? [`${perJob}x`] : [])].join(',');
    const args = CFG.printer ? ['-print-to', CFG.printer] : ['-print-to-default'];
    args.push('-print-settings', settings, '-silent', '-exit-when-done', file);
    for (let k = 0; k < jobs; k++) {
      await new Promise((res, rej) => execFile(exe, args, { timeout: 180000, windowsHide: true }, (e, so, se) => (e ? rej(new Error('SumatraPDF: ' + (se || e.message).toString().slice(0, 160))) : res())));
      if (jobs > 1) await sleep(400);
    }
    return;
  }
  const ptp = require('pdf-to-printer');   // fallback: the library's own bundled SumatraPDF
  for (let k = 0; k < jobs; k++) await ptp.print(file, { ...(CFG.printer ? { printer: CFG.printer } : {}), monochrome: !color, paperSize: paperName, scale: 'fit', copies: perJob, silent: true });
}

// ---------------------------------------------------------------- one print job
let busy = false;
async function runJob(o) {
  const dir = path.join(TMP_ROOT, o.id);
  fs.mkdirSync(dir, { recursive: true });
  const tag = o.token ? '#' + o.token : o.id;
  try {
    const c = await (await api('POST', `agent/claim/${o.id}`)).json();
    if (!c.claimed) { safeRmTemp(dir); return; }
    log(`🖨️  ${tag}  ${o.source === 'whatsapp' ? '💬 WhatsApp' : '🌐 Web'}  ${o.color ? 'COLOR' : 'B&W'} ×${o.copies}  ${o.paper || 'A4'}  (${o.files.length} file${o.files.length > 1 ? 's' : ''})`);
    const pdfs = [], images = [];
    for (let i = 0; i < o.files.length; i++) {
      const f = o.files[i];
      const r = await api('GET', `agent/file/${f.id}`, { timeout: 120000 });
      if (!r.ok) throw new Error('Could not download ' + f.name + ' (expired?)');
      const buf = Buffer.from(await r.arrayBuffer());
      const kind = sniff(buf);
      if (kind === 'pdf') { const p = path.join(dir, `${i}.pdf`); fs.writeFileSync(p, buf); pdfs.push({ i, p }); }
      else if (kind === 'jpg' || kind === 'png') images.push({ i, buf });
      else if (kind === 'webp') throw new Error('WebP images are not supported – ask the customer to resend as JPG/PNG');
      else { const src = path.join(dir, `${i}-${f.name.replace(/[^\w.\-]+/g, '_')}`); fs.writeFileSync(src, buf); pdfs.push({ i, p: await officeToPdf(src, dir) }); }
    }
    if (images.length) {   // all photos of an order go into ONE clean PDF (one photo per page)
      const p = path.join(dir, 'images.pdf');
      fs.writeFileSync(p, await imagesToPdf(images.map((x) => x.buf), o.paper));
      pdfs.push({ i: images[0].i, p });
    }
    pdfs.sort((a, b) => a.i - b.i);
    for (const x of pdfs) await printPdf(x.p, { color: !!o.color, paper: o.paper, copies: o.copies || 1 });
    await api('POST', `agent/printed/${o.id}`);
    log(`✅ ${tag} printed`);
    safeRmTemp(dir);                         // temp copy wiped
    await api('POST', `agent/done/${o.id}`, { json: { pc_deleted: !fs.existsSync(dir) } });
  } catch (e) {
    log(`❌ ${tag} failed: ${e.message}`);
    try { await api('POST', `agent/fail/${o.id}`, { json: { reason: e.message.slice(0, 190) } }); } catch {}
    safeRmTemp(dir);
  }
}
async function poll() {
  if (busy) return; busy = true;
  try {
    const r = await api('GET', 'agent/jobs');
    if (r.ok) for (const o of (await r.json()).orders || []) await runJob(o);
  } catch (e) { log('⚠️  website:', e.message); }
  busy = false;
}

// ---------------------------------------------------------------- WhatsApp bridge
let waState = 'starting', waNumber = '', waClient = null;
async function postStatus(state, qr) {
  waState = state;
  let qrImg = '';
  if (qr) { try { qrImg = await require('qrcode').toDataURL(qr, { margin: 1, width: 300 }); } catch {} }
  emit({ state, qr: qr || '', qrImg, number: waNumber });
  try { await api('POST', 'agent/wa/status', { json: { state, qr: qr || '', number: waNumber, printer: CFG.printer || 'default' }, timeout: 10000 }); } catch {}
}
// ---- branded UPI / Razorpay QR card (PNG) drawn with the Chrome that WhatsApp already uses ----
const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
async function renderPayCard(card) {
  const QR = require('qrcode');
  const qr = card.qrImage || await QR.toDataURL(card.url, { margin: 1, width: 600, errorCorrectionLevel: 'M' });
  const amt = Number(card.amount) % 1 ? Number(card.amount).toFixed(2) : String(Number(card.amount));
  const html = `<!doctype html><meta charset="utf-8"><body style="margin:0;background:#eef2ff;font-family:'Segoe UI','Nirmala UI',Arial,sans-serif">
  <div id="card" style="width:640px;background:#fff;border-radius:34px;overflow:hidden;box-shadow:0 20px 50px rgba(30,41,90,.25)">
   <div style="background:linear-gradient(135deg,#4f5bff,#8b5cf6 60%,#ff5fa2);color:#fff;padding:30px 36px">
     <div style="font-size:34px;font-weight:800;letter-spacing:-.5px">${esc(card.shop || 'therajesh.shop')}</div>
     <div style="opacity:.9;font-size:19px;margin-top:2px">Digital Seva Kendra · UPI Payment</div></div>
   <div style="display:flex;justify-content:space-between;align-items:center;padding:26px 36px 8px">
     <div><div style="color:#64748b;font-size:17px">Token / টোকেন</div><div style="font-size:38px;font-weight:800;color:#3338d6">#${esc(card.token)}</div></div>
     <div style="text-align:right"><div style="color:#64748b;font-size:17px">Amount / মোট</div><div style="font-size:50px;font-weight:900;color:#0f172a">₹${esc(amt)}</div></div></div>
   <div style="text-align:center;padding:10px 36px 6px"><div style="display:inline-block;padding:16px;border:5px solid #4f5bff;border-radius:28px;background:#fff"><img src="${qr}" style="width:360px;height:360px;display:block"></div></div>
   <div style="text-align:center;padding:8px 36px 30px;color:#475569;font-size:19px;line-height:1.5">📲 যেকোনো UPI অ্যাপ দিয়ে স্ক্যান করুন<br><b style="color:#16a34a">Scan with GPay · PhonePe · Paytm · any UPI app</b></div></div></body>`;
  const browser = waClient && waClient.pupBrowser;
  if (!browser) throw new Error('browser not ready');
  const page = await browser.newPage();
  try {
    await page.setViewport({ width: 700, height: 1100, deviceScaleFactor: 2 });
    await page.setContent(html, { waitUntil: card.qrImage ? 'networkidle0' : 'load', timeout: 20000 });
    return await (await page.$('#card')).screenshot({ type: 'png' });
  } finally { try { await page.close(); } catch {} }
}
async function sendReply(chatId, r) {
  if (typeof r === 'string') return waClient.sendMessage(chatId, r);
  const { MessageMedia } = require('whatsapp-web.js');
  if (r.card) {
    let png = null;
    try { png = await renderPayCard(r.card); }
    catch (e) { log('⚠️  payment card failed (' + e.message + ') – sending a plain QR'); try { png = await require('qrcode').toBuffer(r.card.url, { margin: 2, width: 480 }); } catch {} }
    if (png) return waClient.sendMessage(chatId, new MessageMedia('image/png', Buffer.from(png).toString('base64'), 'pay-qr.png'), { caption: r.text });
  }
  return waClient.sendMessage(chatId, r.text || '');
}
// Newer WhatsApp accounts arrive as "<15+ digit id>@lid" (a privacy id, not a phone). Find the real phone so Razorpay / notifications get a valid number.
const phoneCache = new Map();
async function resolvePhone(msg, contact) {
  const from = msg.from, plain = from.split('@')[0].split(':')[0];
  if (!/@lid$/.test(from)) return (contact && contact.number) || plain;
  if (phoneCache.has(from)) return phoneCache.get(from);
  const ok = (n) => { n = String(n || '').split('@')[0].replace(/\D/g, ''); return /^\d{8,14}$/.test(n) ? n : ''; };
  let n = ok(contact && contact.number);                                      // 1) msg.getContact().number
  if (!n && waClient && typeof waClient.getContactLidAndPhone === 'function') {   // 2) client.getContactLidAndPhone([lid])
    try { const r = await waClient.getContactLidAndPhone([from]); const x = Array.isArray(r) ? r[0] : r; n = ok(x && (x.pn || x.phoneNumber || x.phone)); } catch {}
  }
  if (!n && contact && contact.id && contact.id._serialized && !/@lid$/.test(contact.id._serialized)) n = ok(contact.id._serialized);
  if (!n) log('ℹ️  could not resolve a phone for ' + plain.slice(0, 6) + '… (@lid) – payment link will be made without a phone number');
  const out = n || plain;                                                     // keep ONE stable id per customer even if unresolved
  phoneCache.set(from, out);
  return out;
}
let chain = Promise.resolve();   // handle messages strictly one after another (keeps multi-file batches in order)
async function onMessage(msg) {
  if (msg.fromMe || msg.isStatus || /@(g\.us|broadcast|newsletter)$/.test(msg.from)) return;
  const isMedia = msg.hasMedia && ['image', 'document'].includes(msg.type);
  if (!isMedia && msg.type !== 'chat') return;
  let contact = null; try { contact = await msg.getContact(); } catch {}
  const number = await resolvePhone(msg, contact);
  const meta = { from: number, chat: msg.from, name: (contact && (contact.pushname || contact.name)) || '', text: msg.body || '', files: [] };
  const form = new FormData();
  if (isMedia) {
    const m = await msg.downloadMedia();
    if (!m) return;
    const buf = Buffer.from(m.data, 'base64');
    const mime = (m.mimetype || '').split(';')[0];
    const name = m.filename || `whatsapp-${Date.now()}.${{ 'image/jpeg': 'jpg', 'image/png': 'png', 'application/pdf': 'pdf' }[mime] || 'bin'}`;
    let pages = 1; if (sniff(buf) === 'pdf') { try { pages = await pdfPageCount(buf); } catch {} }
    meta.files.push({ name, mime, pages });
    meta.text = msg.body || '';                          // caption
    form.append('files', new Blob([buf], { type: mime }), name);
  }
  form.set('meta', JSON.stringify(meta));
  const r = await api('POST', 'agent/wa/incoming', { form, timeout: 60000 });
  const j = await r.json().catch(() => ({}));
  log(`💬 ${number} ${isMedia ? '[file] ' : ''}${(meta.text || '').slice(0, 30)} -> ${(j.replies || []).length} reply`);
  for (const l of j.logs || []) log('💳 ' + l);          // payment problems from the website show up in the Bot Log
  for (const t of j.replies || []) { await sendReply(msg.from, t); await sleep(700); }
}
async function pumpOutbox() {
  if (waState !== 'ready') return;
  try {
    const r = await api('GET', 'agent/wa/outbox', { timeout: 10000 });
    const msgs = (await r.json()).messages || [];
    const done = [];
    for (const m of msgs) {
      try { await waClient.sendMessage(m.to_id, m.text); } catch (e) { log('⚠️  could not send to', m.to_id, e.message); }
      done.push(m.id); await sleep(600);
    }
    if (done.length) await api('POST', 'agent/wa/ack', { json: { ids: done } });
  } catch {}
}
function startWhatsApp() {
  let wweb, qrt;
  try { wweb = require('whatsapp-web.js'); qrt = require('qrcode-terminal'); } catch { log('⚠️  whatsapp-web.js is not installed – run npm install. Continuing with website jobs only.'); return; }
  const { Client, LocalAuth } = wweb;
  const boot = () => {
    if (isProtected(SESSION_ROOT)) { log('❌ The WhatsApp profile folder is inside a Chrome/Edge folder - refusing to start. Move print-agent elsewhere.'); return; }
    clearChromeLocks();
    waClient = new Client({
      authStrategy: new LocalAuth({ dataPath: SESSION_ROOT }),   // stays linked after restart
      puppeteer: { headless: true, timeout: LAUNCH_TIMEOUT, protocolTimeout: 180000, ...(browserToUse() ? { executablePath: browserToUse() } : {}), args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--disable-gpu-compositing', '--disable-dev-shm-usage', '--disable-extensions', '--renderer-process-limit=2', '--disable-background-networking', '--disable-default-apps', '--disable-sync', '--disable-translate', '--mute-audio', '--no-first-run', '--js-flags=--max-old-space-size=256'] },
    });
    waClient.on('qr', (qr) => { log('📱 Scan this QR with the shop phone:  WhatsApp > Linked devices > Link a device\n'); qrt.generate(qr, { small: true }); postStatus('qr', qr); });
    waClient.on('authenticated', () => { log('🔐 WhatsApp authenticated'); postStatus('authenticated'); });
    waClient.on('auth_failure', (m) => { log('❌ WhatsApp auth failed:', m); postStatus('error'); });
    waClient.on('ready', () => { waNumber = (waClient.info && waClient.info.wid && waClient.info.wid.user) || ''; log('✅ WhatsApp connected  +' + waNumber); postStatus('ready'); });
    waClient.on('disconnected', (why) => { log('⚠️  WhatsApp disconnected:', why, '– reconnecting in 10 s'); postStatus('disconnected'); try { waClient.destroy().catch(() => {}); } catch {} setTimeout(boot, 10000); });
    waClient.on('message', (msg) => { chain = chain.then(() => onMessage(msg)).catch((e) => log('⚠️  message error:', e.message)); });
    log('WhatsApp bot script v4 · profile: ' + SESSION_ROOT + ' · launch timeout ' + (LAUNCH_TIMEOUT / 1000) + ' s · browser: ' + (browserToUse() || 'NOT FOUND') + ' (read-only, your Chrome is never modified)');
    const patch = setInterval(() => {                       // WhatsApp Web waits use the page's default timeout (30 s) -> raise it to 60 s
      const pg = waClient && waClient.pupPage;
      if (pg) { clearInterval(patch); try { pg.setDefaultTimeout(LAUNCH_TIMEOUT); pg.setDefaultNavigationTimeout(LAUNCH_TIMEOUT); } catch {} }
    }, 20);                                                // 20 ms: the page's wait must get the longer timeout before WhatsApp Web's first wait starts
    setTimeout(() => clearInterval(patch), 90000);
    waClient.initialize().catch((e) => {
      clearInterval(patch);
      log('❌ WhatsApp could not start:', e.message, findBrowser() ? '\n   (Browser found: ' + findBrowser() + '. If this repeats: close all Chrome/Edge windows of the bot, then run INSTALL_WHATSAPP.bat to update whatsapp-web.js.)' : '\n   (No Chrome/Edge found - install one or set CHROME_PATH in config.env)');
      postStatus('error');
      try { waClient.destroy().catch(() => {}); } catch {}      // close the half-started browser so the next try gets a free profile
      setTimeout(boot, 30000);
    });
  };
  boot();
  setInterval(pumpOutbox, 5000);
  setInterval(() => postStatus(waState), 30000);   // heartbeat: the counter shows "connected" / "offline"
}

// ---------------------------------------------------------------- start
(async () => {
  if (process.argv.includes('--printers')) {
    const ptp = require('pdf-to-printer');
    (await ptp.getPrinters()).forEach((p) => console.log(' •', p.name));
    return;
  }
  console.log('\n  ┌─────────────────────────────────────────────┐\n  │  Digital Seva Kendra – WhatsApp Bot + Printer │\n  └─────────────────────────────────────────────┘');
  if (!CFG.key) { console.log('\n❌ AGENT_KEY is empty. Open config.env and paste the same AGENT_KEY you set in Cloudflare.\n'); process.exit(1); }
  if (WA_ONLY) {                                             // controlled by printer_agent_gui.py
    process.stdin.setEncoding('utf8');
    let buf = '';
    process.stdin.on('data', async (d) => {
      buf += d; let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const cmd = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (cmd === 'logout') { try { await waClient.logout(); } catch {} emit({ state: 'loggedout' }); process.exit(0); }
        if (cmd === 'quit') { try { await Promise.race([waClient.destroy(), sleep(2500)]); } catch {} process.exit(0); }
      }
    });
    process.stdin.on('end', () => process.exit(0));          // the Python app closed -> do not stay behind as an orphan
    if (!CFG.key) { emit({ state: 'error', msg: 'Agent key missing' }); process.exit(1); }
    log('WhatsApp bot only (printing is done by the Print Agent app)');
    startWhatsApp();
    await new Promise(() => {});
  }
  log('Website :', CFG.site);
  log('Printer :', CFG.printer || '(Windows default printer)');
  log('Browser :', findBrowser() || '❌ none found – install Google Chrome (or set CHROME_PATH in config.env)');
  log('SumatraPDF:', findSumatra() ? 'found' : 'not found – will use pdf-to-printer');
  safeRmTemp(TMP_ROOT); fs.mkdirSync(TMP_ROOT, { recursive: true });
  if (CFG.whatsapp) startWhatsApp(); else log('WhatsApp bridge is OFF (WHATSAPP=off)');
  log('Watching for print jobs…  (Ctrl+C to stop)\n');
  for (;;) { await poll(); await sleep(CFG.poll); }
})();
