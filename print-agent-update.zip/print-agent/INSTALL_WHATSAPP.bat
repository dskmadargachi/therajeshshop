@echo off
cd /d "%~dp0"
title Install WhatsApp parts - Rajesh Print Agent
set PUPPETEER_SKIP_DOWNLOAD=true
echo.
echo  === One-time setup: WhatsApp bot parts for Rajesh Print Agent ===
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js is not installed. Opening the download page - install the LTS version, then run this file again.
  start https://nodejs.org/en/download
  pause
  exit /b 1
)
if not exist local-print-server.js ( echo  local-print-server.js is missing in this folder. & pause & exit /b 1 )
echo  Installing - this takes a few minutes. Internet needed. Google Chrome or Microsoft Edge must be installed on this PC.
call npm install --no-audit --no-fund
if errorlevel 1 (
  echo.
  echo  Install failed. Delete the node_modules folder, check the internet and run this file again.
  pause
  exit /b 1
)
echo ok> .installed
echo.
echo  DONE. Open Rajesh Print Agent - the WhatsApp tab shows the QR code to scan.
pause
