#!/usr/bin/env python3
"""
Agent (GUI)  -  therajesh.shop
Runs on the counter PC. Approve an order on counter.html -> this app prints it
with the right printer & settings, and shows which printers are live.

Build the .exe with BUILD_EXE.bat (see README.txt).
"""
import base64, json, os, platform, queue, re, shutil, subprocess, sys, tempfile, threading, time
import urllib.error, urllib.request
import http.server, socketserver

APP_NAME = "Agent"
APP_USER_MODEL_ID = "therajesh.shop.agent"
IS_WIN = platform.system() == "Windows"
CNW = 0x08000000 if IS_WIN else 0                      # CREATE_NO_WINDOW: no black console flashes
DRY_RUN = os.environ.get("DRY_RUN") == "1"             # test mode: show commands, print nothing
DEFAULT_HINT = "G3010"                                 # default printer = Canon G3010 series
IMG = {"jpg", "jpeg", "png", "webp"}
OFFICE = {"doc", "docx", "xls", "xlsx", "ppt", "pptx"}

ROLES = [  # key, title shown in the app
    ("bw", "Documents  ·  A4 Black & White"),
    ("color", "Documents  ·  A4 Color"),
    ("photo", "Photos  ·  4×6 High Quality"),
    ("a3", "A3 (optional)"),
]
ROLE_TITLE = dict(ROLES)
DEFAULTS = {"site": "https://therajesh.shop", "key": "", "auto": True, "poll": 5,
            "roles": {"bw": "", "color": "", "photo": "", "a3": ""}, "startup": True, "startup_init": False, "tray_hint": False, "photo_fit": "contain", "open_counter": False,
            "sound": True, "theme": "light", "wa_auto": True, "paper_bw": "A4", "paper_color": "A4", "bin_bw": "", "bin_color": "", "copies_mode": "loop", "passport_bg": "white", "removebg_key": ""}
CONFIG_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "RajeshPrintAgent")
CONFIG_FILE = os.path.join(CONFIG_DIR, "settings.json")


# ------------------------------------------------------------------ helpers
def app_dir():
    return os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))


def ext(name):
    return (name.rsplit(".", 1)[-1] if "." in name else "").lower()


def load_cfg():
    cfg = json.loads(json.dumps(DEFAULTS))
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            saved = json.load(f)
        roles = saved.pop("roles", {})
        cfg.update(saved); cfg["roles"].update(roles)
    except Exception:
        pass
    return cfg


def save_cfg(cfg):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


def api(cfg, method, path, body=None, timeout=30):
    data = json.dumps(body).encode() if body is not None else (b"" if method == "POST" else None)
    req = urllib.request.Request(cfg["site"].rstrip("/") + path, data=data, method=method, headers={
        "x-agent-key": cfg["key"], "content-type": "application/json",
        "user-agent": "RajeshPrintAgent/2.0"})           # Cloudflare blocks the default Python user-agent
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode() or "{}")


def download(cfg, file_id, dest):
    req = urllib.request.Request(cfg["site"].rstrip("/") + f"/api/agent/file/{file_id}",
                                 headers={"x-agent-key": cfg["key"], "user-agent": "RajeshPrintAgent/2.0"})
    with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f)


# ------------------------------------------------------------------ printers (live status)
def state_of(work_offline, status):
    """Windows Win32_Printer status -> Online / Printing / Offline / Error"""
    if work_offline or status == 7:
        return "Offline"
    if status == 4:
        return "Printing"
    if status in (1, 6):
        return "Error"
    return "Online"


_WS_BROKEN = False          # set if the built-in Windows printer query misbehaves -> use PowerShell instead
_WS_CHECKED = False


def printer_state_from_winspool(attrs, status):
    """PRINTER_INFO_2 Attributes / Status flags -> Online / Printing / Offline / Error"""
    if attrs & 0x400 or status & (0x80 | 0x1000):                       # work-offline attribute, OFFLINE, NOT_AVAILABLE
        return "Offline"
    if status & (0x1 | 0x2 | 0x8 | 0x10 | 0x40 | 0x200 | 0x40000 | 0x100000 | 0x400000):   # paused, error, jam, paper out/problem, memory, no toner, user help, door open
        return "Error"
    if status & 0x400:                                                  # PRINTING
        return "Printing"
    return "Online"


def _list_printers_winspool():
    """Windows printers straight from the spooler API (ctypes): no PowerShell, no WMI, a few milliseconds."""
    import ctypes
    from ctypes import wintypes as wt
    ws = ctypes.WinDLL("winspool.drv")

    class PI2(ctypes.Structure):
        _fields_ = [("pServerName", wt.LPWSTR), ("pPrinterName", wt.LPWSTR), ("pShareName", wt.LPWSTR), ("pPortName", wt.LPWSTR),
                    ("pDriverName", wt.LPWSTR), ("pComment", wt.LPWSTR), ("pLocation", wt.LPWSTR), ("pDevMode", ctypes.c_void_p),
                    ("pSepFile", wt.LPWSTR), ("pPrintProcessor", wt.LPWSTR), ("pDatatype", wt.LPWSTR), ("pParameters", wt.LPWSTR),
                    ("pSecurityDescriptor", ctypes.c_void_p), ("Attributes", wt.DWORD), ("Priority", wt.DWORD), ("DefaultPriority", wt.DWORD),
                    ("StartTime", wt.DWORD), ("UntilTime", wt.DWORD), ("Status", wt.DWORD), ("cJobs", wt.DWORD), ("AveragePPM", wt.DWORD)]
    flags = 0x2 | 0x4                                                   # PRINTER_ENUM_LOCAL | PRINTER_ENUM_CONNECTIONS
    need, ret = wt.DWORD(0), wt.DWORD(0)
    ws.EnumPrintersW(flags, None, 2, None, 0, ctypes.byref(need), ctypes.byref(ret))
    if not need.value:
        return []
    buf = (ctypes.c_byte * need.value)()
    if not ws.EnumPrintersW(flags, None, 2, buf, need.value, ctypes.byref(need), ctypes.byref(ret)):
        raise OSError("EnumPrintersW failed")
    arr = ctypes.cast(buf, ctypes.POINTER(PI2))
    n = wt.DWORD(0)
    ws.GetDefaultPrinterW(None, ctypes.byref(n))
    dflt = ""
    if n.value:
        b2 = ctypes.create_unicode_buffer(n.value)
        if ws.GetDefaultPrinterW(b2, ctypes.byref(n)):
            dflt = b2.value
    out = []
    for i in range(ret.value):
        p = arr[i]
        if not p.pPrinterName:
            raise OSError("bad printer record")
        out.append({"name": p.pPrinterName, "state": printer_state_from_winspool(p.Attributes, p.Status), "default": p.pPrinterName == dflt})
    return out


def list_printers():
    global _WS_BROKEN, _WS_CHECKED
    """-> [{'name','state','default'}]"""
    fake = os.environ.get("FAKE_PRINTERS")
    if fake:
        return json.loads(fake)
    out = []
    try:
        if IS_WIN:
            if not _WS_BROKEN:
                try:
                    got = _list_printers_winspool()
                    if got or _WS_CHECKED:
                        return got
                    _WS_CHECKED = True               # empty list: double-check ONCE with PowerShell that there really are no printers
                except Exception:
                    _WS_BROKEN = True
            ps = ("Get-CimInstance Win32_Printer | Select-Object Name,WorkOffline,PrinterStatus,Default "
                  "| ConvertTo-Json -Compress")
            r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                               timeout=25, creationflags=CNW)
            data = json.loads(r.stdout or "[]")
            for d in ([data] if isinstance(data, dict) else data):
                out.append({"name": d["Name"], "state": state_of(d.get("WorkOffline"), d.get("PrinterStatus")),
                            "default": bool(d.get("Default"))})
            if out and not _WS_BROKEN:
                _WS_BROKEN = True                    # the fast query said "no printers" but PowerShell found some -> never trust the fast one
        elif shutil.which("lpstat"):
            r = subprocess.run(["lpstat", "-p"], capture_output=True, text=True, timeout=10)
            for line in r.stdout.splitlines():
                p = line.split()
                if len(p) > 2 and p[0] == "printer":
                    out.append({"name": p[1], "state": "Offline" if "disabled" in line else "Online", "default": False})
    except Exception:
        pass
    return out


def pick_default(printers, photo=False):
    names = [p["name"] for p in printers]
    hit = [n for n in names if DEFAULT_HINT.lower() in n.lower()]
    if photo:
        ph = [n for n in hit if "photo" in n.lower() or "4x6" in n.lower()]
        if ph:
            return ph[0]
    if hit:
        # for non-photo roles avoid the photo queue
        plain = [n for n in hit if "photo" not in n.lower() and "4x6" not in n.lower()]
        return (plain or hit)[0]
    for p in printers:
        if p.get("default"):
            return p["name"]
    return names[0] if names else ""


# ------------------------------------------------------------------ icon / taskbar identity
LOGO_SVG = ('<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="pg" x1="0" y1="0" x2="1" y2="1">'
            '<stop offset="0" stop-color="#7C3AED"/><stop offset="1" stop-color="#6366F1"/></linearGradient></defs>'
            '<rect width="100" height="100" rx="22.5" fill="url(#pg)"/><rect x="30" y="19" width="40" height="21" rx="3" fill="#fff"/>'
            '<rect x="16" y="36" width="68" height="32" rx="9" fill="#fff"/><rect x="30" y="56" width="40" height="27" rx="3" fill="#fff" stroke="#6D4AEA" stroke-width="2.4"/>'
            '<path d="M37 65h26M37 72h21" stroke="#6D4AEA" stroke-width="2.4" stroke-linecap="round"/><circle cx="73.5" cy="47.5" r="3.5" fill="#6D4AEA"/></svg>')


def icon_path():
    """assets/printer.ico: bundled inside the .exe (PyInstaller --add-data) or next to the script."""
    for base in (getattr(sys, "_MEIPASS", None), app_dir(), os.path.dirname(os.path.abspath(__file__))):
        if base:
            p = os.path.join(base, "assets", "printer.ico")
            if os.path.exists(p):
                return p
    return ""


def set_app_user_model_id():
    """Own taskbar identity (otherwise Windows groups the window under python.exe and shows Python's icon). Call BEFORE any window exists."""
    if IS_WIN:
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
        except Exception:
            pass


def apply_window_icon(title=None, tries=40):
    """Puts printer.ico on this process's window(s): title bar, taskbar and Alt+Tab (pywebview ignores its icon option on Windows)."""
    ico = icon_path()
    if not (IS_WIN and ico):
        return False
    import ctypes
    from ctypes import wintypes
    title = title or APP_NAME
    u32 = ctypes.windll.user32
    u32.LoadImageW.restype = wintypes.HANDLE
    u32.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    u32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    LR_LOADFROMFILE, IMAGE_ICON, WM_SETICON = 0x10, 1, 0x80
    big = u32.LoadImageW(None, ico, IMAGE_ICON, 256, 256, LR_LOADFROMFILE)
    small = u32.LoadImageW(None, ico, IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
    if not (big or small):
        return False
    mypid, done = os.getpid(), [False]
    EnumProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def each(hwnd, _):
        pid = wintypes.DWORD()
        u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == mypid:
            buf = ctypes.create_unicode_buffer(256); u32.GetWindowTextW(hwnd, buf, 256)
            if buf.value.startswith(title):
                if small: u32.SendMessageW(hwnd, WM_SETICON, 0, small)     # ICON_SMALL (title bar)
                if big: u32.SendMessageW(hwnd, WM_SETICON, 1, big)         # ICON_BIG   (taskbar, Alt+Tab)
                done[0] = True
        return True
    for _ in range(tries):                                                # the window may not exist yet: retry for ~10 s
        u32.EnumWindows(EnumProc(each), 0)
        if done[0]:
            return True
        time.sleep(0.25)
    return False


# ------------------------------------------------------------------ printing
def find_sumatra():
    base = getattr(sys, "_MEIPASS", app_dir())
    for p in [os.path.join(base, "SumatraPDF.exe"), os.path.join(app_dir(), "SumatraPDF.exe"),
              r"C:\Program Files\SumatraPDF\SumatraPDF.exe", r"C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe",
              os.path.expandvars(r"%LOCALAPPDATA%\SumatraPDF\SumatraPDF.exe")]:
        if os.path.exists(p):
            return p
    raise RuntimeError("SumatraPDF.exe not found (rebuild the app with SumatraPDF.exe in the folder)")


def run(cmd, log):
    if DRY_RUN:
        log("   [dry-run] " + " ".join(f'"{c}"' if " " in str(c) else str(c) for c in cmd))
        return
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300, creationflags=CNW)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout or f"print command failed ({r.returncode})").strip()[:150])


PRINT_OPTS = {"paper_bw": "A4", "paper_color": "A4", "bin_bw": "", "bin_color": "", "copies_mode": "loop"}   # paper size / tray per printer type (Printers tab)
PHOTO_FIT = "contain"   # "contain" = whole photo visible (same as the preview) | "cover" = fill the 4x6, crop edges

# Prints a JPG/PNG straight through Windows (GDI+) on the REAL 4x6 paper size of the printer queue.
# SumatraPDF can't select 4x6 and its forced landscape/portrait + "fit" is what distorted the photos.
PHOTO_PS = r'''
param([string]$Printer,[string]$ImgPath,[int]$Copies,[string]$Fit,[int]$Loop=1)
$ErrorActionPreference = 'Stop'
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Text.RegularExpressions;

public static class PhotoPrinter
{
    public static string Print(string printer, string file, int copies, string fit, bool loop)
    {
        string info = "";
        using (Image img = Image.FromFile(file))
        {
            try
            {
                int o = (int)img.GetPropertyItem(0x0112).Value[0];
                if (o == 3) img.RotateFlip(RotateFlipType.Rotate180FlipNone);
                else if (o == 6) img.RotateFlip(RotateFlipType.Rotate90FlipNone);
                else if (o == 8) img.RotateFlip(RotateFlipType.Rotate270FlipNone);
            }
            catch { }
            if (img.Width > img.Height) img.RotateFlip(RotateFlipType.Rotate90FlipNone);

            PrintDocument pd = new PrintDocument();
            pd.PrinterSettings.PrinterName = printer;
            if (!pd.PrinterSettings.IsValid) throw new Exception("Printer not found: " + printer);
            pd.PrinterSettings.Copies = (short)(loop ? 1 : copies);      // loop: every copy is its own job - drivers that ignore the copies setting still print N
            pd.PrintController = new StandardPrintController();
            pd.DefaultPageSettings.Margins = new Margins(0, 0, 0, 0);
            pd.DefaultPageSettings.Landscape = false;

            PaperSize found = null;
            foreach (PaperSize s in pd.PrinterSettings.PaperSizes)
            {
                bool bySize = Math.Abs(s.Width - 400) <= 10 && Math.Abs(s.Height - 600) <= 10;
                bool byName = Regex.IsMatch(s.PaperName, "4\\s*[xX\\\"]\\s*6|10\\s*[xX]\\s*15");
                if (bySize || byName) { found = s; break; }
            }
            if (found != null) { pd.DefaultPageSettings.PaperSize = found; info = "paper=" + found.PaperName; }
            else info = "paper=NOT FOUND (using queue default) - set Paper 4x6 in Photo quality settings";

            pd.PrintPage += delegate(object sender, PrintPageEventArgs e)
            {
                Graphics g = e.Graphics;
                g.TranslateTransform(-e.PageSettings.HardMarginX, -e.PageSettings.HardMarginY);
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.SmoothingMode = SmoothingMode.HighQuality;
                double pw = e.PageBounds.Width, ph = e.PageBounds.Height;
                double iw = img.Width, ih = img.Height;
                double ir = iw / ih, pr = pw / ph;
                RectangleF src, dst;
                if (fit == "cover")
                {
                    double sw, sh;
                    if (ir > pr) { sh = ih; sw = sh * pr; } else { sw = iw; sh = sw / pr; }
                    src = new RectangleF((float)((iw - sw) / 2), (float)((ih - sh) / 2), (float)sw, (float)sh);
                    dst = new RectangleF(0f, 0f, (float)pw, (float)ph);
                }
                else
                {
                    double dw, dh;
                    if (ir > pr) { dw = pw; dh = pw / ir; } else { dh = ph; dw = ph * ir; }
                    src = new RectangleF(0f, 0f, (float)iw, (float)ih);
                    dst = new RectangleF((float)((pw - dw) / 2), (float)((ph - dh) / 2), (float)dw, (float)dh);
                }
                g.DrawImage(img, dst, src, GraphicsUnit.Pixel);
                e.HasMorePages = false;
            };
            for (int k = 0; k < (loop ? copies : 1); k++) pd.Print();
        }
        return info;
    }
}
"@
Write-Output ([PhotoPrinter]::Print($Printer, $ImgPath, $Copies, $Fit, ($Loop -ne 0)))
'''


def print_photo_gdi(path, copies, printer, log):
    ps1 = os.path.join(os.path.dirname(path), "photo_print.ps1")
    with open(ps1, "w", encoding="utf-8-sig") as f:
        f.write(PHOTO_PS)
    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps1,
           "-Printer", printer, "-ImgPath", path, "-Copies", str(copies), "-Fit", PHOTO_FIT,
           "-Loop", "0" if (PRINT_OPTS.get("copies_mode") or "loop") == "driver" else "1"]
    if DRY_RUN:
        log("   [dry-run] " + " ".join(f'"{c}"' if " " in str(c) else str(c) for c in cmd)); return
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300, creationflags=CNW)
    if r.stdout.strip():
        log("   " + r.stdout.strip().replace("\n", " | "))
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout or "photo print failed").strip()[:150])


def is_passport(o):
    try: kind = json.loads(o.get("opts") or "{}").get("kind")
    except Exception: kind = None
    return kind == "passport" and (o.get("paper") or "") == "4x6" and bool(o.get("files"))


def passport_sheets(src, copies, outdir, cfg, log):
    """Photo -> background removed -> 35x45 mm face-centred crop -> 4x6 sheet PNG(s) at 300 DPI (see passport_sheet.py)."""
    import passport_sheet                              # bundled next to the app (also shipped as a data file for the external-python rembg call)
    return passport_sheet.build_passport_sheets(src, copies, outdir, cfg.get("passport_bg") or "white", log, cfg.get("removebg_key") or read_config_env("REMOVEBG_API_KEY"))


def print_one(order, path, name, orient, role, printer, log):
    copies = max(1, int(order.get("copies") or 1))
    x = ext(name)
    if IS_WIN and role == "photo" and x in ("jpg", "jpeg", "png"):
        return print_photo_gdi(path, copies, printer, log)
    if x in OFFICE:
        soffice = shutil.which("soffice") or next((p for p in (r"C:\Program Files\LibreOffice\program\soffice.exe",
                                                               r"C:\Program Files (x86)\LibreOffice\program\soffice.exe") if os.path.exists(p)), None)
        if soffice:
            out = tempfile.mkdtemp(prefix="conv_")
            run([soffice, "--headless", "--convert-to", "pdf", "--outdir", out, path], log)
            pdf = os.path.join(out, os.path.splitext(os.path.basename(path))[0] + ".pdf")
            if DRY_RUN and not os.path.exists(pdf):
                pdf = path
            return print_one(order, pdf, os.path.basename(pdf), orient, role, printer, log)
        if IS_WIN:
            log("   (Office file without LibreOffice: printed by its own app, default settings)")
            for _ in range(copies):
                if DRY_RUN: log(f"   [dry-run] printto {path} -> {printer}")
                else: os.startfile(path, "printto", f'"{printer}"'); time.sleep(8)
            return
        raise RuntimeError("Install LibreOffice to print Word/Excel/PowerPoint")

    if IS_WIN:
        # SumatraPDF's copy syntax is "Nx" (e.g. "5x"). The old "copies=5" is not part of its grammar -> it was ignored and ONE copy came out.
        # copies_mode "loop" (default): N separate 1-copy jobs = exactly N prints on every driver (Canon G-series ignore dmCopies);
        # copies_mode "driver": one job with "Nx" (faster, only if the driver honours it).
        jobs, per_job = (1, copies) if (PRINT_OPTS.get("copies_mode") or "loop") == "driver" else (copies, 1)
        s = ([f"{per_job}x"] if per_job > 1 else []) + ["fit"]
        if role in ("bw", "color"):
            s += ["monochrome" if role == "bw" else "color", "paper=" + (PRINT_OPTS.get("paper_" + role) or "A4")]
            b = re.sub(r"\D", "", PRINT_OPTS.get("bin_" + role) or "")
            if b: s.append("bin=" + b)
        elif role == "photo":
            s += ["color"]                       # paper size + HIGH quality come from the photo queue's saved preferences
        elif role == "a3":
            s += ["color" if order.get("color") else "monochrome", "paper=A3"]
        if x in IMG and role != "photo" and orient in ("landscape", "portrait"):   # forced orientation distorted 4x6 prints
            s.append(orient)
        cmd = ["SumatraPDF.exe" if DRY_RUN else find_sumatra(), "-print-to", printer,
               "-print-settings", ",".join(s), "-silent", path]
        for k in range(jobs):
            run(cmd, log)
            if jobs > 1:
                log(f"   copy {k + 1}/{jobs} sent")
                if k < jobs - 1 and not DRY_RUN: time.sleep(0.4)
    else:                                         # macOS/Linux (CUPS) - for testing
        cmd = ["lp", "-d", printer, "-n", str(copies), "-o", "fit-to-page",
               "-o", "print-color-mode=" + ("monochrome" if role == "bw" else "color")]
        if role == "photo":
            cmd += ["-o", "media=4x6", "-o", "print-quality=5"]
        elif role in ("bw", "color"):
            cmd += ["-o", "media=" + (PRINT_OPTS.get("paper_" + role) or "A4")]
        run(cmd + [path], log)


# ------------------------------------------------------------------ the agent (background worker)
class Agent:
    def __init__(self, cfg, ui):
        self.cfg, self.ui = cfg, ui
        self.stop = threading.Event()
        self.paused = False
        self.force = queue.Queue()
        self.pending = {}
        self.printers = []
        self.warned = set()
        self.last_conn = None
        self.warned_net = False
        self.shop = ""
        self.last_ok = None
        self.wake = threading.Event()      # set() = poll the website right now

    # -- printers refresh thread
    pwake = threading.Event()        # set() = re-scan the printers right now
    idle = False                      # True while the window is hidden in the tray -> everything polls more slowly
    _rescan_ts = 0.0

    def printers_loop(self):
        """One printer scan at a time (single thread, nothing can pile up). Every 20 s (60 s while hidden) – and at once when asked."""
        while not self.stop.is_set():
            try:
                new = list_printers()
                if new or not self.printers:
                    if new != self.printers:
                        self.printers = new
                        self.ui.event("printers")
            except Exception:
                pass
            self.pwake.wait(60 if self.idle else 20); self.pwake.clear()

    def pstate(self, name):
        for p in self.printers:
            if p["name"] == name:
                return p["state"]
        return None

    # -- routing: which printer/profile does this order use?
    def route(self, o):
        paper = o.get("paper") or "A4"
        role = "photo" if paper == "4x6" else "a3" if paper == "A3" else ("color" if o.get("color") else "bw")
        return role, self.cfg["roles"].get(role, "")

    def summary(self, o, role):
        n = len(o.get("files", []))
        mode = "Passport photos (4×6 sheet)" if is_passport(o) else "Photo 4×6 HQ" if role == "photo" else ("Color" if o.get("color") else "B&W")
        return f"{n} file(s) · ×{o.get('copies')} · {mode} · {o.get('paper') or 'A4'}"

    def conn(self, state):
        if state != self.last_conn:
            self.last_conn = state
            self.ui.event("conn", state)

    def fail(self, oid, reason):
        self.ui.log(f"FAILED {oid}: {reason}")
        try: api(self.cfg, "POST", f"/api/agent/fail/{oid}", {"reason": reason[:180]})
        except Exception: pass

    def process(self, o):
        oid = o["id"]; role, printer = self.route(o); summ = self.summary(o, role)
        if not printer:
            self.ui.job(oid, summ, "✖ No printer chosen"); return self.fail(oid, f"No printer chosen for {ROLE_TITLE[role]}")
        if self.pstate(printer) == "Offline" and time.time() - self._rescan_ts > 10:
            self._rescan_ts = time.time()            # the cached state may be up to 20 s old: look again before holding the job
            try: self.printers = list_printers()
            except Exception: pass
        if self.pstate(printer) == "Offline":
            if oid not in self.warned:
                self.warned.add(oid); self.ui.log(f"{printer} is OFFLINE - order {oid} is waiting. Turn the printer on.")
            self.ui.job(oid, summ, "⚠ Printer offline - waiting"); return
        try:
            if not api(self.cfg, "POST", f"/api/agent/claim/{oid}").get("claimed"):
                return
        except Exception:
            return
        self.warned.discard(oid); self.pending.pop(oid, None)
        self.ui.job(oid, summ, "🖨 Printing…")
        self.ui.log(f"PRINTING {oid} on '{printer}': {summ}")
        tmp = tempfile.mkdtemp(prefix=f"order_{oid}_")
        try:
            try: orient = json.loads(o.get("opts") or "{}").get("orient") or []
            except Exception: orient = []
            if is_passport(o):                                         # WhatsApp option 3: background removal + 4x6 passport sheet(s)
                f = o["files"][0]
                safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in f["name"]) or "photo.jpg"
                p = os.path.join(tmp, "src_" + safe); download(self.cfg, f["id"], p)
                self.ui.log("   passport photo: removing background and building the 4x6 sheet(s)…")
                sheets = passport_sheets(p, max(1, int(o.get("copies") or 6)), tmp, self.cfg, self.ui.log)
                for n, sp in enumerate(sheets, 1):
                    print_one(dict(o, copies=1), sp, os.path.basename(sp), None, "photo", printer, self.ui.log)     # each sheet once; N photos are ON the sheet
                    self.ui.log(f"   sent: passport sheet {n}/{len(sheets)}")
            else:
              for i, f in enumerate(o["files"]):
                safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in f["name"]) or f"file{i}"
                p = os.path.join(tmp, f"{i}_{safe}")
                download(self.cfg, f["id"], p)
                print_one(o, p, f["name"], orient[i] if i < len(orient) else None, role, printer, self.ui.log)
                self.ui.log(f"   sent: {f['name']}")
            try: api(self.cfg, "POST", f"/api/agent/printed/{oid}")      # customer's tracker: Print done
            except Exception: pass
            self.ui.job(oid, summ, "✔ Printed")
            shutil.rmtree(tmp, ignore_errors=True)                       # 1) wipe the temporary copy from this PC
            pc_ok = not os.path.exists(tmp)
            self.ui.log(f"   temporary files wiped from this PC: {'yes' if pc_ok else 'NO - check folder ' + tmp}")
            api(self.cfg, "POST", f"/api/agent/done/{oid}", {"pc_deleted": pc_ok})   # 2) then the server deletes its copy
            self.ui.log(f"DONE {oid} (files deleted from this PC and from the server)")
        except Exception as e:
            self.ui.job(oid, summ, "✖ Failed: " + str(e)[:60]); self.fail(oid, str(e))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def poll_once(self):
        orders = api(self.cfg, "GET", "/api/agent/jobs").get("orders", [])
        self.conn("ok"); self.warned_net = False; self.last_ok = time.time()
        if not self.shop:
            try: self.shop = str(api(self.cfg, "GET", "/api/config").get("shop") or "")
            except Exception: pass
        ids = {o["id"] for o in orders}
        forced = set()
        while not self.force.empty():
            forced.add(self.force.get())
        for o in orders:
            if self.cfg["auto"] or o["id"] in forced:
                self.process(o)
            else:
                role, _ = self.route(o)
                self.pending[o["id"]] = o
                self.ui.job(o["id"], self.summary(o, role), "⏸ Waiting - press Print")
        for gone in [i for i in self.pending if i not in ids]:
            self.pending.pop(gone, None); self.ui.job_remove(gone)

    def loop(self):
        while not self.stop.is_set():
            if self.paused:
                self.conn("paused")
            else:
                try:
                    self.poll_once()
                except urllib.error.HTTPError as e:
                    if e.code == 401:
                        self.conn("badkey")
                    else:
                        self.conn("offline")
                except Exception as e:
                    self.conn("offline")
                    if not self.warned_net:
                        self.warned_net = True; self.ui.log(f"Waiting for internet/server… ({e})")
            self.wake.wait(max(8.0 if self.idle else 5.0, float(self.cfg.get("poll", 5)))); self.wake.clear()


# ------------------------------------------------------------------ counter (admin page) window
PROXY_PORT = None          # set when the local counter bridge is running
KEY_PLACEHOLDER = "__agent__"      # the page only ever sees this; the real agent key is added by the local bridge below


def counter_url(cfg):
    from urllib.parse import quote
    if PROXY_PORT:                                       # embedded counter: served by the local bridge below (same origin, agent key added by the agent)
        return f"http://127.0.0.1:{PROXY_PORT}/counter.html"
    u = cfg["site"].rstrip("/") + "/counter.html"
    return u + ("#key=" + quote(cfg["key"], safe="") if cfg.get("key") else "")          # the page signs in from this and clears it


def check_admin(cfg):
    """Asks the website whether the saved agent key may open the counter -> none / ok / wrong / offline / error"""
    key = cfg.get("key") or ""
    if not key: return "none"
    try:
        req = urllib.request.Request(cfg["site"].rstrip("/") + "/api/admin/ping",
                                     headers={"x-agent-key": key, "user-agent": "RajeshPrintAgent/2.0"})
        urllib.request.urlopen(req, timeout=15).read(); return "ok"
    except urllib.error.HTTPError as e:
        return "wrong" if e.code in (401, 403) else "error"
    except urllib.error.URLError:
        return "offline"
    except Exception:
        return "error"


SHIM = ("<script>(function(){try{sessionStorage.setItem('__t','1');sessionStorage.removeItem('__t')}catch(e){"
        "var m={};try{Object.defineProperty(window,'sessionStorage',{configurable:true,value:{getItem:function(k){return k in m?m[k]:null},"
        "setItem:function(k,v){m[k]=String(v)},removeItem:function(k){delete m[k]},clear:function(){m={}}}})}catch(e2){}}"
        "%s})();</script>")


def start_counter_proxy(cfg):
    """Tiny local web server (127.0.0.1 only). The counter page + its /api calls go through it, so the page is
    same-origin inside the agent window and the saved AGENT KEY is added here - no Google login or browser storage needed."""
    holder = {}

    class H(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.0"
        def log_message(self, *a): pass

        def _send(self, code, body=b"", ctype="text/plain; charset=utf-8", extra=None):
            self.send_response(code); self.send_header("content-type", ctype); self.send_header("cache-control", "no-store")
            self.send_header("content-length", str(len(body)))
            for k, v in (extra or {}).items(): self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD": self.wfile.write(body)

        def _go(self):
            me = f"127.0.0.1:{holder['port']}"
            org = self.headers.get("origin")
            if self.headers.get("host") != me or (org and org not in (f"http://{me}", "null")):
                return self._send(403, b"forbidden")                       # other websites can't drive the admin session
            path = self.path
            base = path.split("?")[0]
            if base in ("/", "/counter", "/index.html"):
                return self._send(302, b"", extra={"location": "/counter.html"})
            if base not in ("/counter.html", "/site-ui.js", "/site-theme.css") and not base.startswith("/api/"):
                return self._send(404, b"not found")
            n = int(self.headers.get("content-length") or 0)
            data = self.rfile.read(n) if n else None
            hd = {"user-agent": "RajeshPrintAgent/2.0", "accept": self.headers.get("accept", "*/*")}
            if self.headers.get("content-type"): hd["content-type"] = self.headers["content-type"]
            if base.startswith("/api/admin/"):
                if cfg.get("key"): hd["x-agent-key"] = cfg["key"]          # always the real key; whatever the page sent is ignored
            req = urllib.request.Request(cfg["site"].rstrip("/") + path, data=data, method=self.command, headers=hd)
            try:
                r = urllib.request.urlopen(req, timeout=120); code = r.status
            except urllib.error.HTTPError as e:
                r = e; code = e.code
            except Exception as e:
                return self._send(502, ("Cannot reach " + cfg["site"] + ": " + str(e)).encode())
            body = r.read(); ct = r.headers.get("content-type") or "application/octet-stream"
            extra = {"content-disposition": r.headers["content-disposition"]} if r.headers.get("content-disposition") else None
            if base == "/counter.html" and code == 200:
                pre = "try{sessionStorage.setItem('agentkey','%s')}catch(e){}" % KEY_PLACEHOLDER if cfg.get("key") else ""
                html = body.decode("utf-8", "replace")
                html = html.replace("<head>", "<head>" + SHIM % pre, 1) if "<head>" in html else SHIM % pre + html
                body = html.encode("utf-8")
            self._send(code, body, ct, extra)

        do_GET = do_POST = do_HEAD = _go

    class Srv(socketserver.ThreadingMixIn, http.server.HTTPServer):
        daemon_threads = True

    srv = Srv(("127.0.0.1", 0), H)
    holder["port"] = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, holder["port"]


def find_edge():
    for p in (shutil.which("msedge"), r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
              r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
              r"C:\Program Files\Google\Chrome\Application\chrome.exe",
              r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"):
        if p and os.path.exists(p):
            return p
    return None


def run_counter():
    """Runs in its own process (python printer_agent_gui.py --counter): the admin page in a plain app window."""
    cfg = load_cfg(); url = counter_url(cfg)
    try:
        import webview                                   # pip install pywebview  (uses Edge WebView2 on Windows)
        webview.create_window("Agent  ·  Counter", url, width=1320, height=860, min_size=(900, 600))
        webview.start(private_mode=False, storage_path=os.path.join(CONFIG_DIR, "webview"))
        return
    except ImportError:
        pass
    edge = find_edge()
    if edge:                                              # Edge/Chrome "app mode" = a window with no tabs or address bar
        prof = os.path.join(CONFIG_DIR, "counter_profile"); os.makedirs(prof, exist_ok=True)
        subprocess.call([edge, f"--app={url}", f"--user-data-dir={prof}", "--window-size=1320,860"])
    else:
        import webbrowser; webbrowser.open(url)


# ------------------------------------------------------------------ GUI
BG, CARD, BORDER = "#f1f5f9", "#ffffff", "#e2e8f0"
NAVY, INK, MUTE = "#1e3a6e", "#0f172a", "#64748b"
GREEN, GREEN_BG, RED, RED_BG = "#16a34a", "#ecfdf3", "#dc2626", "#fef2f2"
BLUE, BLUE_BG, AMBER, AMBER_BG, GREY_BG = "#2563eb", "#eff6ff", "#d97706", "#fffbeb", "#f1f5f9"
FONT = "Segoe UI"
CARDS = [  # role, number, icon, title, subtitle
    ("bw", "1", "🖨", "Black & White", "For normal B&W prints (A4)"),
    ("color", "2", "🎨", "Color Printer", "For color prints (A4)"),
    ("a3", "3", "📄", "A3 Printer", "For A3 size prints (optional)"),
    ("photo", "4", "🖼", "4 × 6 Photo Printer", "For 4×6 photo prints"),
]


def ago(ts):
    if not ts:
        return "—"
    d = int(time.time() - ts)
    return "Now" if d < 6 else f"{d}s ago" if d < 90 else f"{d // 60} min ago" if d < 7200 else f"{d // 3600} h ago"


def run_gui():
    global PHOTO_FIT
    counter_proc = [None]
    import tkinter as tk
    import webbrowser
    from tkinter import ttk, messagebox, scrolledtext

    class UI:  # thread-safe bridge: worker threads -> main thread
        def __init__(self): self.q = queue.Queue()
        def log(self, m): self.q.put(("log", m))
        def job(self, oid, summ, status): self.q.put(("job", oid, summ, status))
        def job_remove(self, oid): self.q.put(("jobdel", oid))
        def event(self, name, arg=None): self.q.put((name, arg))

    cfg = load_cfg()
    PHOTO_FIT = cfg.get("photo_fit") or PHOTO_FIT
    ui = UI()
    agent = Agent(cfg, ui)
    root = tk.Tk()
    root.title(APP_NAME + "  ·  therajesh.shop")
    try:
        if icon_path(): root.iconbitmap(icon_path())
    except Exception:
        pass
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"{min(1200, sw - 40)}x{min(880, sh - 80)}+{max(0, (sw - 1200) // 2)}+10")
    root.minsize(980, 640); root.configure(bg=BG)

    style = ttk.Style()
    try: style.theme_use("clam")
    except Exception: pass
    style.configure("TCombobox", fieldbackground="#ffffff", background="#ffffff", foreground=INK, padding=8, arrowsize=16)
    style.configure("Treeview", font=(FONT, 10), rowheight=26, background="#ffffff", fieldbackground="#ffffff")
    style.configure("Treeview.Heading", font=(FONT, 10, "bold"), background="#e2e8f0")
    style.configure("TNotebook", background=BG)
    style.configure("TNotebook.Tab", font=(FONT, 10, "bold"), padding=(14, 6))
    root.option_add("*TCombobox*Listbox.font", (FONT, 10))

    # ---------- small widget helpers
    def card(parent, **kw):
        return tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1, **kw)

    def lab(parent, text, size=10, bold=False, fg=INK, bg=CARD, **kw):
        return tk.Label(parent, text=text, font=(FONT, size, "bold" if bold else "normal"), fg=fg, bg=bg, **kw)

    def clickable(frame, cmd, hover=None):
        base = frame.cget("bg")
        def paint_all(c):
            frame.configure(bg=c)
            for w in frame.winfo_children():
                try: w.configure(bg=c)
                except Exception: pass
        def inside(w):
            while w is not None:
                if w is frame: return True
                w = getattr(w, "master", None)
            return False
        def leave(_=None):
            def chk():
                try:
                    x, y = frame.winfo_pointerxy()
                    if not inside(frame.winfo_containing(x, y)): paint_all(base)
                except Exception: pass
            frame.after(15, chk)
        for w in [frame] + list(frame.winfo_children()):
            w.bind("<Button-1>", lambda e: cmd()); w.configure(cursor="hand2")
            if hover:
                w.bind("<Enter>", lambda e: paint_all(hover)); w.bind("<Leave>", leave)

    def big_button(parent, title, sub, cmd, bg, hover, fg="#ffffff", subfg=None):
        f = tk.Frame(parent, bg=bg, padx=18, pady=12)
        t = tk.Label(f, text=title, font=(FONT, 12, "bold"), fg=fg, bg=bg, anchor="w")
        t.pack(fill="x")
        s = tk.Label(f, text=sub, font=(FONT, 9), fg=subfg or fg, bg=bg, anchor="w") if sub else None
        if s: s.pack(fill="x")
        clickable(f, cmd, hover)
        f.title_label = t
        return f

    def pill(parent, text, fg, bg):
        return tk.Label(parent, text=text, font=(FONT, 9, "bold"), fg=fg, bg=bg, padx=10, pady=3)

    def toast(msg):
        ui.log(msg)

    # =====================================================  HEADER
    wrap = tk.Frame(root, bg=BG); wrap.pack(fill="both", expand=True, padx=14, pady=10)
    head = card(wrap); head.pack(fill="x")
    hl = tk.Frame(head, bg=CARD); hl.pack(side="left", padx=20, pady=14)
    logo = tk.Canvas(hl, width=62, height=62, bg=CARD, highlightthickness=0); logo.pack(side="left")
    logo.create_oval(2, 2, 60, 60, fill="#7C3AED", outline="")
    logo.create_text(31, 31, text="🖨", font=(FONT, 24), fill="#ffffff")
    tt = tk.Frame(hl, bg=CARD); tt.pack(side="left", padx=14)
    lab(tt, "Agent", 22, True, NAVY).pack(anchor="w")
    lab(tt, "therajesh.shop  ·  Reliable  •  Secure  •  Instant", 9, False, MUTE).pack(anchor="w")

    hr = tk.Frame(head, bg=CARD); hr.pack(side="right", padx=18, pady=14)
    counter_b = tk.Button(hr, text="🖥  Open Counter", font=(FONT, 10, "bold"), bg=BLUE, fg="#ffffff", bd=0, padx=14, pady=8, cursor="hand2",
                          activebackground="#1d4ed8", activeforeground="#ffffff")
    counter_b.pack(side="right", padx=(14, 0))
    settings_b = tk.Button(hr, text="⚙  Settings", font=(FONT, 10, "bold"), bg="#e2e8f0", fg=INK, bd=0, padx=14, pady=8, cursor="hand2")
    settings_b.pack(side="right", padx=(14, 0))
    sync_box = tk.Frame(hr, bg=CARD); sync_box.pack(side="right", padx=14)
    lab(sync_box, "Last Sync", 9, False, MUTE).pack(anchor="w")
    sync_v = lab(sync_box, "—", 13, True, INK); sync_v.pack(anchor="w")
    status_box = tk.Frame(hr, bg=GREY_BG, padx=16, pady=8); status_box.pack(side="right", padx=10)
    status_t = tk.Label(status_box, text="●  Starting…", font=(FONT, 12, "bold"), fg=MUTE, bg=GREY_BG); status_t.pack(anchor="w")
    status_s = tk.Label(status_box, text="Please wait", font=(FONT, 9), fg=MUTE, bg=GREY_BG); status_s.pack(anchor="w")
    qr_box = tk.Frame(hr, bg=CARD); qr_box.pack(side="right", padx=16)
    lab(qr_box, "Your Shop QR Poster", 11, True, INK).pack(anchor="w")
    lab(qr_box, "Customers scan it to send files", 9, False, MUTE).pack(anchor="w")
    poster_b = tk.Button(qr_box, text="⬇  Open QR Poster", font=(FONT, 10, "bold"), bg="#e11d48", fg="#ffffff", bd=0, padx=14, pady=6, cursor="hand2",
                         activebackground="#be123c", activeforeground="#ffffff")
    poster_b.pack(anchor="w", pady=(4, 0))
    poster_b.config(command=lambda: webbrowser.open(cfg["site"].rstrip("/") + "/poster.html"))

    # =====================================================  INFO ROW
    info = card(wrap); info.pack(fill="x", pady=(10, 0))
    def info_cell(title):
        f = tk.Frame(info, bg=CARD); f.pack(side="left", padx=22, pady=10)
        lab(f, title, 9, False, MUTE).pack(anchor="w")
        return f
    c1 = info_cell("Shop"); shop_v = lab(c1, "—", 12, True); shop_v.pack(anchor="w")
    c2 = info_cell("Website"); site_v_l = lab(c2, cfg["site"].replace("https://", ""), 12, True); site_v_l.pack(anchor="w")
    c3 = info_cell("Connected to server"); conn_v = lab(c3, "● No", 12, True, RED); conn_v.pack(anchor="w")

    c4 = tk.Frame(info, bg=GREEN_BG, highlightbackground="#bbf7d0", highlightthickness=1, padx=14, pady=6); c4.pack(side="right", padx=14, pady=10)
    auto_txt = tk.Frame(c4, bg=GREEN_BG); auto_txt.pack(side="left", padx=(0, 12))
    lab(auto_txt, "Auto Print", 9, False, MUTE, GREEN_BG).pack(anchor="w")
    auto_state = lab(auto_txt, "ON", 12, True, GREEN, GREEN_BG); auto_state.pack(anchor="w")
    sw_cv = tk.Canvas(c4, width=56, height=28, bg=GREEN_BG, highlightthickness=0, cursor="hand2"); sw_cv.pack(side="left")
    def draw_switch():
        on = cfg["auto"]
        col = GREEN if on else "#94a3b8"
        c4.configure(bg=GREEN_BG if on else GREY_BG); auto_txt.configure(bg=GREEN_BG if on else GREY_BG)
        for w in auto_txt.winfo_children(): w.configure(bg=GREEN_BG if on else GREY_BG)
        sw_cv.configure(bg=GREEN_BG if on else GREY_BG); sw_cv.delete("all")
        sw_cv.create_oval(2, 2, 28, 26, fill=col, outline=col); sw_cv.create_oval(28, 2, 54, 26, fill=col, outline=col); sw_cv.create_rectangle(15, 2, 41, 26, fill=col, outline=col)
        x = 41 if on else 15
        sw_cv.create_oval(x - 11, 4, x + 11, 24, fill="#ffffff", outline="")
        auto_state.config(text="ON" if on else "OFF", fg=GREEN if on else MUTE)
    def toggle_auto(_=None):
        cfg["auto"] = not cfg["auto"]; save_cfg(cfg); draw_switch()
        toast("Auto Print ON – prints the moment an order is approved / paid." if cfg["auto"] else "Auto Print OFF – approved jobs wait; select them in Jobs and press Print.")
    sw_cv.bind("<Button-1>", toggle_auto)

    # =====================================================  PRINTER SETUP
    ps = card(wrap); ps.pack(fill="x", pady=(10, 0))
    ph_ = tk.Frame(ps, bg=CARD); ph_.pack(fill="x", padx=18, pady=(14, 6))
    lab(ph_, "🖨", 20).pack(side="left")
    pt_ = tk.Frame(ph_, bg=CARD); pt_.pack(side="left", padx=10)
    lab(pt_, "Printer Setup", 15, True, NAVY).pack(anchor="w")
    lab(pt_, "Choose which printer is used for each type of job", 9, False, MUTE).pack(anchor="w")

    grid = tk.Frame(ps, bg=CARD); grid.pack(fill="x", padx=12, pady=(4, 14))
    for i in range(4): grid.columnconfigure(i, weight=1, uniform="c")
    role_v, role_status, role_cb = {}, {}, {}
    fit_v = tk.StringVar(value=cfg.get("photo_fit") or PHOTO_FIT)

    def on_role(k):
        cfg["roles"][k] = role_v[k].get(); save_cfg(cfg); paint()

    def prefs(k):
        n = role_v[k].get()
        if not n: return messagebox.showinfo(APP_NAME, "Choose a printer first.")
        if IS_WIN: subprocess.Popen(["rundll32", "printui.dll,PrintUIEntry", "/e", "/n", n], creationflags=CNW)

    def make_queue():
        src = role_v["color"].get() or role_v["bw"].get()
        if not src or not IS_WIN: return messagebox.showinfo(APP_NAME, "Choose the A4 printer first (Windows only).")
        new = f"{src} (Photo 4x6)"
        script = ("$p=Get-Printer -Name '%s'; Add-Printer -Name '%s' -DriverName $p.DriverName -PortName $p.PortName" % (src.replace("'", "''"), new.replace("'", "''")))
        enc = base64.b64encode(script.encode("utf-16-le")).decode()
        subprocess.Popen(["powershell", "-NoProfile", "-Command",
                          f"Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-EncodedCommand','{enc}'"], creationflags=CNW)
        messagebox.showinfo(APP_NAME, f"Windows will ask for permission (Yes). It creates a second queue:\n{new}\n\n"
                                      "Then choose it for 4×6 Photos and click ‘Photo quality settings’.")

    def on_fit():
        global PHOTO_FIT
        PHOTO_FIT = fit_v.get(); cfg["photo_fit"] = PHOTO_FIT; save_cfg(cfg)

    for col, (k, num, icon, title, sub) in enumerate(CARDS):
        c = tk.Frame(grid, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        c.grid(row=0, column=col, sticky="nsew", padx=6, pady=4)
        top = tk.Frame(c, bg=CARD); top.pack(fill="x", padx=10, pady=(10, 0))
        badge = tk.Canvas(top, width=28, height=28, bg=CARD, highlightthickness=0); badge.pack(side="left")
        badge.create_oval(1, 1, 27, 27, fill=NAVY, outline=""); badge.create_text(14, 14, text=num, fill="#ffffff", font=(FONT, 10, "bold"))
        lab(c, icon, 26).pack(pady=(0, 2))
        lab(c, title, 13, True).pack()
        lab(c, sub, 9, False, MUTE).pack(pady=(0, 8))
        role_v[k] = tk.StringVar(value=cfg["roles"].get(k, ""))
        cb = ttk.Combobox(c, textvariable=role_v[k], state="readonly", font=(FONT, 10)); cb.pack(fill="x", padx=12, pady=(0, 8))
        cb.bind("<<ComboboxSelected>>", lambda e, k=k: on_role(k)); role_cb[k] = cb
        tk.Frame(c, bg=BORDER, height=1).pack(fill="x", padx=12, pady=4)
        body = tk.Frame(c, bg=CARD); body.pack(fill="both", expand=True, padx=12, pady=4)
        if k == "photo":
            lab(body, "Photo fit", 10, True).pack(anchor="w")
            for val, txt in (("contain", "Whole photo (no crop)"), ("cover", "Fill 4×6 (crop edges)")):
                tk.Radiobutton(body, text=txt, value=val, variable=fit_v, command=on_fit, font=(FONT, 10), bg=CARD, activebackground=CARD,
                               anchor="w", selectcolor="#ffffff").pack(fill="x")
            tk.Button(body, text="⚙  Photo quality settings…", font=(FONT, 9, "bold"), bg=GREY_BG, fg=INK, bd=0, pady=5, cursor="hand2",
                      command=lambda: prefs("photo")).pack(fill="x", pady=(6, 2))
            tk.Button(body, text="＋  Create photo queue (admin)", font=(FONT, 9, "bold"), bg=GREY_BG, fg=INK, bd=0, pady=5, cursor="hand2",
                      command=make_queue).pack(fill="x", pady=2)
        else:
            lab(body, "Paper & quality", 10, True).pack(anchor="w")
            lab(body, "Uses the settings saved in the Windows printer preferences.", 9, False, MUTE, wraplength=200, justify="left").pack(anchor="w", pady=(2, 6))
            tk.Button(body, text="⚙  Printer preferences…", font=(FONT, 9, "bold"), bg=GREY_BG, fg=INK, bd=0, pady=5, cursor="hand2",
                      command=lambda k=k: prefs(k)).pack(fill="x")
        role_status[k] = tk.Label(c, text="Select a printer", font=(FONT, 10, "bold"), fg=MUTE, bg=GREY_BG, pady=7)
        role_status[k].pack(fill="x", padx=12, pady=(6, 12))

    # =====================================================  ACTION BAR
    bar = tk.Frame(wrap, bg=BG); bar.pack(fill="x", pady=(10, 0))
    for i in range(3): bar.columnconfigure(i, weight=1, uniform="b")
    def save_all():
        save_cfg(cfg); toast("Settings saved.")
        save_btn.title_label.config(text="✔  Saved"); root.after(1500, lambda: save_btn.title_label.config(text="💾  Save Settings"))
    def sync_now():
        agent.wake.set(); toast("Checking for new print jobs…")
    def refresh_printers():
        threading.Thread(target=lambda: (setattr(agent, "printers", list_printers()), ui.event("printers")), daemon=True).start()
        toast("Printer list refreshed.")
    save_btn = big_button(bar, "💾  Save Settings", "Save all printer choices", save_all, NAVY, "#162c55")
    save_btn.grid(row=0, column=0, sticky="ew", padx=(0, 6))
    sync_btn = big_button(bar, "🔄  Sync Now", "Check for new print jobs right now", sync_now, GREEN, "#15803d")
    sync_btn.grid(row=0, column=1, sticky="ew", padx=6)
    ref_btn = big_button(bar, "📋  Refresh Printer List", "Detect newly connected printers", refresh_printers, "#e2e8f0", "#cbd5e1", fg=INK, subfg=MUTE)
    ref_btn.grid(row=0, column=2, sticky="ew", padx=(6, 0))
    pause_btn = big_button(wrap, "⏸  Pause Printing", "", lambda: toggle_pause(), "#f59e0b", "#d97706")
    pause_btn.pack(fill="x", pady=(8, 0))
    def toggle_pause():
        agent.paused = not agent.paused
        pause_btn.title_label.config(text="▶  Resume Printing" if agent.paused else "⏸  Pause Printing")
        if not agent.paused: agent.wake.set()
        else: conn_event("paused")

    # =====================================================  JOBS + LOG
    nb = ttk.Notebook(wrap); nb.pack(fill="both", expand=True, pady=(10, 0))
    jf, lf = tk.Frame(nb, bg=CARD), tk.Frame(nb, bg=CARD); nb.add(jf, text="  Jobs  "); nb.add(lf, text="  Log  ")
    jtree = ttk.Treeview(jf, columns=("id", "what", "st"), show="headings", height=4)
    for cname, t, w in (("id", "Order", 90), ("what", "Details", 420), ("st", "Status", 300)):
        jtree.heading(cname, text=t); jtree.column(cname, width=w)
    jtree.pack(fill="both", expand=True, padx=6, pady=(6, 2))
    def print_sel():
        for it in jtree.selection():
            agent.force.put(str(it)); agent.wake.set()   # row id == order id
    tk.Button(jf, text="🖨  Print selected (when Auto Print is OFF)", font=(FONT, 10, "bold"), bg=BLUE, fg="#ffffff", bd=0, padx=14, pady=6,
              cursor="hand2", command=print_sel).pack(anchor="e", padx=6, pady=4)
    logbox = scrolledtext.ScrolledText(lf, height=4, state="disabled", font=("Consolas", 9)); logbox.pack(fill="both", expand=True, padx=6, pady=6)

    foot = tk.Frame(root, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
    wrap.pack_forget(); foot.pack(fill="x", side="bottom"); wrap.pack(fill="both", expand=True, padx=14, pady=10)   # footer always visible
    lab(foot, "🔒  PRIVACY BY DESIGN", 9, True, GREEN).pack(side="left", padx=(16, 8), pady=6)
    lab(foot, "Files are deleted automatically right after printing", 9, False, MUTE).pack(side="left")
    lab(foot, "🌐  therajesh.shop   ·   Made with ❤ by Rajesh Das", 9, True, NAVY).pack(side="right", padx=16)

    # =====================================================  SETTINGS DIALOG
    def open_settings(first=False):
        d = tk.Toplevel(root); d.title("Connection settings"); d.configure(bg=CARD); d.resizable(False, False)
        d.transient(root); d.geometry(f"520x360+{root.winfo_x() + 200}+{root.winfo_y() + 120}")
        lab(d, "Connection settings", 15, True, NAVY).pack(anchor="w", padx=22, pady=(18, 4))
        lab(d, "The agent key must match AGENT_KEY in Cloudflare.", 9, False, MUTE).pack(anchor="w", padx=22)
        sv, kv, stv = tk.StringVar(value=cfg["site"]), tk.StringVar(value=cfg["key"]), tk.BooleanVar(value=cfg["startup"])
        lab(d, "Website", 10, True).pack(anchor="w", padx=22, pady=(12, 2))
        tk.Entry(d, textvariable=sv, font=(FONT, 11), relief="solid", bd=1).pack(fill="x", padx=22, ipady=5)
        lab(d, "Agent key", 10, True).pack(anchor="w", padx=22, pady=(10, 2))
        ke = tk.Entry(d, textvariable=kv, font=(FONT, 11), show="•", relief="solid", bd=1); ke.pack(fill="x", padx=22, ipady=5)
        ocv = tk.BooleanVar(value=cfg.get("open_counter", False))
        tk.Checkbutton(d, text="Open the counter window when this agent starts", variable=ocv, font=(FONT, 10), bg=CARD, activebackground=CARD).pack(anchor="w", padx=20, pady=(8, 0))
        tk.Checkbutton(d, text="Start automatically with Windows", variable=stv, font=(FONT, 10), bg=CARD, activebackground=CARD).pack(anchor="w", padx=20, pady=(10, 0))
        def save():
            cfg["site"], cfg["key"] = sv.get().strip(), kv.get().strip()
            cfg["open_counter"] = bool(ocv.get())
            if stv.get() != cfg["startup"]: cfg["startup"] = stv.get(); apply_startup()
            save_cfg(cfg); site_v_l.config(text=cfg["site"].replace("https://", "")); agent.shop = ""; agent.wake.set()
            toast("Connection saved."); d.destroy()
        tk.Button(d, text="Save", font=(FONT, 11, "bold"), bg=NAVY, fg="#ffffff", bd=0, padx=26, pady=8, cursor="hand2", command=save).pack(anchor="e", padx=22, pady=14)
        ke.focus_set()
    settings_b.config(command=open_settings)

    def open_counter():
        if counter_proc[0] is not None and counter_proc[0].poll() is None:
            return messagebox.showinfo(APP_NAME, "The counter window is already open (check your taskbar).")
        cmd = ([sys.executable, "--counter"] if getattr(sys, "frozen", False) else [sys.executable, os.path.abspath(__file__), "--counter"])
        counter_proc[0] = subprocess.Popen(cmd)
        ui.log("Counter opened." + ("" if cfg.get("key") else "  (Save your Agent key in Settings so the counter can sign in.)"))
    counter_b.config(command=open_counter)

    def apply_startup():
        lnk = os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup", "RajeshPrintAgent.lnk")
        if not IS_WIN: return
        if cfg["startup"] and getattr(sys, "frozen", False):
            ps_ = ("$s=(New-Object -COM WScript.Shell).CreateShortcut('%s');$s.TargetPath='%s';$s.WorkingDirectory='%s';$s.Save()" % (lnk, sys.executable, app_dir()))
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_], creationflags=CNW)
            ui.log("Will start automatically with Windows.")
        elif cfg["startup"]:
            ui.log("Start-with-Windows works from the .exe version only (or put START_PRINT_AGENT.bat in the Startup folder).")
        elif os.path.exists(lnk):
            os.remove(lnk); ui.log("Will NOT start with Windows.")

    # =====================================================  LIVE UPDATES
    def add_log(m):
        logbox.config(state="normal"); logbox.insert("end", time.strftime("%H:%M:%S ") + m + "\n"); logbox.see("end"); logbox.config(state="disabled")

    STATE_UI = {"Online": ("●  Printer Ready", GREEN, GREEN_BG), "Printing": ("●  Printing…", BLUE, BLUE_BG),
                "Offline": ("●  Printer Offline", RED, RED_BG), "Error": ("●  Printer Error", AMBER, AMBER_BG)}
    def paint():
        by = {p["name"]: p["state"] for p in agent.printers}
        for k in role_status:
            name = role_v[k].get(); st = by.get(name)
            if not name: txt, fg, bg = "Select a printer", MUTE, GREY_BG
            elif st is None: txt, fg, bg = "●  Printer not found", RED, RED_BG
            else: txt, fg, bg = STATE_UI.get(st, ("●  " + st, MUTE, GREY_BG))
            role_status[k].config(text=txt, fg=fg, bg=bg)

    def printers_event():
        names = [p["name"] for p in agent.printers]
        for k, *_ in CARDS:
            role_cb[k]["values"] = ([""] if k == "a3" else []) + names
            if not role_v[k].get() and names and k != "a3":   # first run: default Canon G3010
                role_v[k].set(pick_default(agent.printers, photo=(k == "photo"))); cfg["roles"][k] = role_v[k].get(); save_cfg(cfg)
        paint()

    def conn_event(s):
        chip = {"ok": ("●  Agent Online", "Connected & Ready", GREEN, GREEN_BG),
                "badkey": ("●  Wrong Agent Key", "Open Settings and fix the key", RED, RED_BG),
                "offline": ("●  Offline", "No internet / website unreachable", RED, RED_BG),
                "paused": ("●  Paused", "Printing is on hold", AMBER, AMBER_BG)}.get(s, ("●  …", "", MUTE, GREY_BG))
        status_box.config(bg=chip[3]); status_t.config(text=chip[0], fg=chip[2], bg=chip[3]); status_s.config(text=chip[1], fg=chip[2], bg=chip[3])
        conn_v.config(text="● Yes" if s == "ok" else "● No", fg=GREEN if s == "ok" else RED)

    def job_event(oid, summ, st):
        if jtree.exists(oid):
            jtree.item(oid, values=(oid, summ, st)); return
        jtree.insert("", 0, iid=oid, values=(oid, summ, st))
        for it in jtree.get_children()[60:]: jtree.delete(it)

    def drain():
        try:
            while True:
                m = ui.q.get_nowait()
                if m[0] == "log": add_log(m[1])
                elif m[0] == "job": job_event(m[1], m[2], m[3])
                elif m[0] == "jobdel":
                    if jtree.exists(m[1]) and "Waiting" in str(jtree.item(m[1])["values"][2]): jtree.delete(m[1])
                elif m[0] == "printers": printers_event()
                elif m[0] == "conn": conn_event(m[1])
        except queue.Empty:
            pass
        root.after(250, drain)

    def tick():
        sync_v.config(text=ago(agent.last_ok))
        shop_v.config(text=agent.shop or "—")
        root.after(1000, tick)

    def on_close():
        if messagebox.askyesno(APP_NAME, "Close the agent?\nPrinting will STOP until you open it again."):
            agent.stop.set(); agent.wake.set(); root.destroy()
    root.protocol("WM_DELETE_WINDOW", on_close)

    draw_switch()
    threading.Thread(target=agent.printers_loop, daemon=True).start()
    threading.Thread(target=agent.loop, daemon=True).start()
    drain(); tick()
    if cfg.get("open_counter") and cfg["key"]: root.after(1500, open_counter)
    if not cfg["key"]:
        add_log("Enter your Agent key (same as AGENT_KEY in Cloudflare) in Settings.")
        root.after(400, lambda: open_settings(True))
    root.mainloop()



# ------------------------------------------------------------------ built-in web window (Agent + Counter tabs in ONE window)
from collections import deque


def apply_startup(cfg, log):
    lnk = os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup", "RajeshPrintAgent.lnk")
    if not IS_WIN:
        return
    if cfg["startup"]:
        if getattr(sys, "frozen", False):
            target, args = sys.executable, "--background"
        else:
            pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
            target, args = (pyw if os.path.exists(pyw) else sys.executable), f'"{os.path.abspath(__file__)}" --background'
        ps_ = ("$s=(New-Object -COM WScript.Shell).CreateShortcut('%s');$s.TargetPath='%s';$s.Arguments='%s';$s.WorkingDirectory='%s';$s.Save()"
               % (lnk, target, args.replace("'", "''"), app_dir()))
        subprocess.run(["powershell", "-NoProfile", "-Command", ps_], creationflags=CNW)
        log("Will start automatically with Windows.")
    elif os.path.exists(lnk):
        os.remove(lnk); log("Will NOT start with Windows.")


def open_printer_prefs(name):
    if IS_WIN and name:
        subprocess.Popen(["rundll32", "printui.dll,PrintUIEntry", "/e", "/n", name], creationflags=CNW)


def create_photo_queue(src):
    new = f"{src} (Photo 4x6)"
    script = ("$p=Get-Printer -Name '%s'; Add-Printer -Name '%s' -DriverName $p.DriverName -PortName $p.PortName" % (src.replace("'", "''"), new.replace("'", "''")))
    enc = base64.b64encode(script.encode("utf-16-le")).decode()
    subprocess.Popen(["powershell", "-NoProfile", "-Command",
                      f"Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-EncodedCommand','{enc}'"], creationflags=CNW)
    return new




# ------------------------------------------------------------------ WhatsApp bridge (local-print-server.js --wa-only) run as a child process
CHROME_LOCKS = ("SingletonLock", "SingletonSocket", "SingletonCookie")     # the ONLY files the bot's cleanup ever deletes - and only inside <app>\\.wa-session

# The installed Google Chrome / Edge (program files AND the user's own profile) must NEVER be touched by this program.
_PROTECTED = ("google\\chrome", "\\chrome\\user data", "microsoft\\edge", "\\edge\\user data", "/google-chrome", "/.config/google-chrome", "/.config/chromium")


def is_protected_path(p):
    q = os.path.normcase(os.path.abspath(str(p))).replace("/", "\\").lower()
    return any(x.replace("/", "\\") in q for x in _PROTECTED)


def inside(path, root):
    try:
        a, b = os.path.normcase(os.path.realpath(path)), os.path.normcase(os.path.realpath(root))
        return a == b or a.startswith(b + os.sep)
    except Exception:
        return False


def safe_remove_lock(path, session_root):
    """Deletes ONE lock file - refuses anything that is not a Chromium lock inside our own .wa-session folder."""
    if os.path.basename(path) not in CHROME_LOCKS or not inside(path, session_root) or is_protected_path(path):
        return False
    if os.path.lexists(path):
        os.remove(path); return True
    return False


def read_config_env(key):
    """Value of KEY in config.env (same file local-print-server.js reads), or ''."""
    try:
        for line in open(os.path.join(app_dir(), "config.env"), encoding="utf-8", errors="replace"):
            m = re.match(r"\s*" + re.escape(key) + r"\s*=\s*(.*?)\s*$", line)
            if m and not line.strip().startswith("#"): return m.group(1).strip("\"'")
    except Exception:
        pass
    return ""


def find_browser():
    """chrome.exe / msedge.exe: CHROME_PATH (config.env or environment) first, then the usual install folders and the Windows registry."""
    la, pf, pf86 = os.environ.get("LOCALAPPDATA", ""), os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    cands = [os.environ.get("CHROME_PATH", "").strip(), read_config_env("CHROME_PATH"),
             os.path.join(pf, r"Google\Chrome\Application\chrome.exe"), os.path.join(pf86, r"Google\Chrome\Application\chrome.exe"), os.path.join(la, r"Google\Chrome\Application\chrome.exe"),
             os.path.join(pf86, r"Microsoft\Edge\Application\msedge.exe"), os.path.join(pf, r"Microsoft\Edge\Application\msedge.exe"), os.path.join(la, r"Microsoft\Edge\Application\msedge.exe")]
    if IS_WIN:
        try:
            import winreg
            for exe in ("chrome.exe", "msedge.exe"):
                for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                    try:
                        with winreg.OpenKey(root, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths" + "\\" + exe) as k: cands.append(winreg.QueryValue(k, None))
                    except OSError:
                        pass
        except Exception:
            pass
    else:
        cands += [shutil.which(x) or "" for x in ("google-chrome", "chromium", "chromium-browser")]
    return next((c for c in cands if c and os.path.isfile(c)), "")


def write_config_env(key, value):
    """Sets KEY=value in config.env (replaces the line, or appends it; creates the file if missing). Keeps the file's own line endings."""
    f = os.path.join(app_dir(), "config.env")
    try: raw = open(f, encoding="utf-8", errors="replace", newline="").read()
    except OSError: raw = ""
    nl = "\r\n" if "\r\n" in raw else "\n"
    lines, done = raw.split(nl) if raw else [], False
    for i, line in enumerate(lines):
        if re.match(r"\s*" + re.escape(key) + r"\s*=", line) and not line.lstrip().startswith("#"):
            lines[i] = f"{key}={value}"; done = True; break
    while lines and lines[-1] == "": lines.pop()
    if not done:
        lines.append(f"{key}={value}")
    open(f, "w", encoding="utf-8", newline="").write(nl.join(lines) + nl)


def ensure_chrome_path(log=print):
    """Before the bot starts: if CHROME_PATH in config.env is empty / points to a missing file, find Chrome or Edge and write the real path into config.env."""
    cur = read_config_env("CHROME_PATH")
    if cur and os.path.isfile(cur):
        return cur
    found = find_browser()                      # Chrome (Program Files, Program Files x86, LocalAppData) then Edge; a missing configured path is skipped
    if not found:
        log("No Chrome / Edge found - install Google Chrome or Microsoft Edge, then restart the bot.")
        return ""
    try:
        write_config_env("CHROME_PATH", found)
        log(("CHROME_PATH in config.env was %s - " % ("wrong (" + cur + ")" if cur else "empty")) + "set to " + found)
    except Exception as e:
        log(f"Found {found} but could not write config.env ({e}); using it for this run only.")
    return found


def node_exe():
    p = shutil.which("node")
    if p:
        return p
    for c in (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files (x86)\nodejs\node.exe", os.path.expandvars(r"%LOCALAPPDATA%\Programs\nodejs\node.exe")):
        if os.path.exists(c):
            return c
    return None


def kill_tree(proc):
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, creationflags=CNW, timeout=15)
        else:
            proc.kill()
    except Exception:
        pass


class WaBridge:
    """Starts / stops the Node WhatsApp bot and keeps its live status (QR code, connected number) for the window."""
    SCRIPT = "local-print-server.js"

    def __init__(self, cfg, st):
        self.cfg, self.st = cfg, st
        self.proc = None
        self.want = False
        self.state = "stopped"          # stopped starting qr authenticated ready disconnected error | missing problems: no_script no_node no_modules no_key
        self.qr = ""; self.qr_img = ""; self.number = ""
        self.lines = deque(maxlen=150)
        self.lock = threading.Lock()
        self.installing = False
        self.quick_crashes = 0
        self._env_cache = (0.0, None)   # (time, problem) - node/modules checks are cached so the 1-second UI poll never touches the disk/PATH
        self._start_lock = threading.Lock()

    def session_dir(self):
        return os.path.join(app_dir(), ".wa-session")

    def pid_file(self):
        return os.path.join(app_dir(), ".wa-bot.pid")

    def script(self):
        return os.path.join(app_dir(), self.SCRIPT)

    def problem(self):
        t, v = self._env_cache
        if time.time() - t > 5:                                  # cached 5 s
            v = ("no_script" if not os.path.exists(self.script()) else "no_node" if not node_exe()
                 else "no_modules" if not os.path.isdir(os.path.join(app_dir(), "node_modules", "whatsapp-web.js")) else None)
            self._env_cache = (time.time(), v)
        if v: return v
        return None if self.cfg.get("key") else "no_key"

    # ---- leftovers of an earlier run: orphan bot / Chrome that still hold .wa-session, and Chromium lock files
    def kill_orphans(self):
        """Ends every process of an earlier run: the bot (node ... --wa-only) and any Chrome/Edge using our .wa-session profile. Whole trees (taskkill /F /T)."""
        pids = set()          # found ONLY by command line (our .wa-session folder / our bot script) - never by a stored PID, which Windows may have given to another program
        if is_protected_path(self.session_dir()):
            self.log("Refusing to clean up: the WhatsApp profile folder points into a Chrome/Edge folder."); return
        if IS_WIN:
            sd, sc = self.session_dir().replace("'", "''"), self.script().replace("'", "''")
            ps_ = ("$sd='%s';$sc='%s';Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.ProcessId -ne %d -and $_.ProcessId -ne $PID -and "
                   "( $_.CommandLine.IndexOf($sd,[StringComparison]::OrdinalIgnoreCase) -ge 0 -or "
                   "($_.CommandLine.IndexOf($sc,[StringComparison]::OrdinalIgnoreCase) -ge 0 -and $_.CommandLine.Contains('--wa-only')) ) } | ForEach-Object { $_.ProcessId }") % (sd, sc, os.getpid())
            try:
                r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_], capture_output=True, text=True, creationflags=CNW, timeout=25)
                pids.update(int(x) for x in r.stdout.split() if x.strip().isdigit())
            except Exception as e:
                self.log(f"Could not scan for leftover processes: {e}")
            for pid in pids:
                try: subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True, creationflags=CNW, timeout=15)
                except Exception: pass
        else:
            try: subprocess.run(["pkill", "-f", self.session_dir()], capture_output=True, timeout=10)
            except Exception: pass
        if pids: self.log(f"Closed {len(pids)} leftover process(es) from an earlier run.")

    def clear_locks(self):
        """Deletes Chromium's stale SingletonLock / SingletonSocket / SingletonCookie in .wa-session (our own folder only) so the bot's browser can open its profile."""
        root, n = self.session_dir(), 0
        if is_protected_path(root): return 0
        try: dirs = [root] + [os.path.join(root, d) for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))]
        except OSError: return 0
        for d in dirs:
            for name in CHROME_LOCKS:
                f = os.path.join(d, name)
                for attempt in range(3):                       # Windows may release the handle a moment after the process died
                    try:
                        if safe_remove_lock(f, root): n += 1
                        break
                    except OSError:
                        time.sleep(0.4)
        if n: self.log(f"Removed {n} stale browser lock file(s).")
        return n

    def running(self):
        return bool(self.proc and self.proc.poll() is None)

    def log(self, m):
        with self.lock: self.lines.append(time.strftime("%H:%M:%S ") + str(m))

    def start(self):
        """Blocking (cleanup + launch): ALWAYS call from a worker thread - see start_async()."""
        if self.running(): return True
        pr = self.problem()
        if pr:
            self.state = pr; return False
        if not self._start_lock.acquire(blocking=False): return True        # another thread is already starting it
        try:
            self.state = "starting"; self.want = True
            ensure_chrome_path(self.log)                                    # fixes CHROME_PATH in config.env before the bot is launched
            self.kill_orphans(); self.clear_locks()                         # leftovers of a crashed/previous run would lock .wa-session
            return self._launch()
        finally:
            self._start_lock.release()

    def start_async(self):
        threading.Thread(target=self.start, daemon=True).start()

    def _launch(self):
        env = dict(os.environ, SITE_URL=self.cfg["site"], AGENT_KEY=self.cfg["key"], WHATSAPP="on", PUPPETEER_SKIP_DOWNLOAD="true", PYTHONIOENCODING="utf-8", NODE_OPTIONS="--max-old-space-size=192")
        if not os.environ.get("CHROME_PATH") and not read_config_env("CHROME_PATH"):
            b = find_browser()                                             # CHROME_PATH empty -> auto-detect Chrome / Edge
            if b: env["CHROME_PATH"] = b; self.log("Browser: " + b)
            else: self.log("No Chrome / Edge found - install Google Chrome or Microsoft Edge (or set CHROME_PATH in config.env).")
        try:
            self.proc = subprocess.Popen([node_exe(), self.script(), "--wa-only"], cwd=app_dir(), env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, creationflags=CNW | (0x4000 if IS_WIN else 0), text=True, encoding="utf-8", errors="replace", bufsize=1)   # 0x4000 = BELOW_NORMAL priority: the bot (and its Chrome) never slows the PC or printing
        except Exception as e:
            self.state = "error"; self.log(f"Could not start WhatsApp bot: {e}"); return False
        self.want = True; self.state = "starting"; self.qr = self.qr_img = ""
        self.t0 = time.time()
        self.log("WhatsApp bot starting…")
        threading.Thread(target=self._read, args=(self.proc,), daemon=True).start()
        return True

    def _read(self, proc):
        try:
            for raw in proc.stdout:
                line = raw.rstrip()
                if line.startswith("@@WA "):
                    try: self._event(json.loads(line[5:]))
                    except Exception: pass
                elif line.strip():
                    self.log(line[:200])
        except Exception:
            pass
        proc.wait()
        if self.want and proc is self.proc:            # it stopped by itself -> bring it back (a few times)
            self.state = "disconnected"
            self.quick_crashes = self.quick_crashes + 1 if time.time() - self.t0 < 30 else 0
            if self.quick_crashes >= 4:
                self.state = "error"; self.log("WhatsApp bot keeps stopping – check the log above (Chrome/Edge installed? run INSTALL_WHATSAPP.bat).")
                return
            self.log("WhatsApp bot stopped – restarting in 8 s…")
            time.sleep(8)
            if self.want and proc is self.proc:
                self.proc = None; self.start()

    def _event(self, d):
        s = d.get("state")
        if s == "qr":
            self.qr, self.qr_img, self.state = d.get("qr", ""), d.get("qrImg", ""), "qr"
        elif s in ("authenticated", "ready", "disconnected", "error", "starting"):
            self.state = s; self.qr = self.qr_img = ""
            if s == "ready":
                self.number = d.get("number", ""); self.quick_crashes = 0; self.log("WhatsApp connected +" + self.number)
        elif s == "loggedout":
            self.state = "stopped"; self.number = ""

    def stop(self):
        self.want = False
        p = self.proc
        if p and p.poll() is None:
            try: p.stdin.write("quit\n"); p.stdin.flush()                 # polite: the bot closes its own browser
            except Exception: pass
            try: p.wait(2)
            except Exception: pass
        if p: kill_tree(p)                                                  # taskkill /F /T /PID: the whole tree, even if node already exited
        self.proc = None
        self.kill_orphans(); self.clear_locks()                             # nothing is left holding .wa-session
        if self.state not in ("no_node", "no_modules", "no_script", "no_key"): self.state = "stopped"
        self.qr = self.qr_img = ""

    def reconnect(self):
        self.stop(); time.sleep(1); return self.start()

    def logout(self):
        """Unlink the shop's WhatsApp (phone side too) and show a fresh QR."""
        p = self.proc
        if p and p.poll() is None:
            try: p.stdin.write("logout\n"); p.stdin.flush()
            except Exception: pass
            try: p.wait(12)
            except Exception: pass
        self.stop()
        sess = os.path.join(app_dir(), ".wa-session")
        if os.path.basename(sess) == ".wa-session" and not is_protected_path(sess):      # only our own isolated profile, never a browser folder
            shutil.rmtree(sess, ignore_errors=True)
        self.number = ""; self.log("WhatsApp unlinked. Starting again for a new QR code…")
        time.sleep(1); return self.start()

    def install(self):
        if self.installing: return False
        npm = shutil.which("npm")
        if not npm or not node_exe():
            self.state = "no_node"; return False
        self.installing = True; self.log("Installing WhatsApp parts (npm install) – this takes a few minutes…")

        def go():
            try:
                pr = subprocess.Popen([npm, "install", "--no-audit", "--no-fund"], cwd=app_dir(), env=dict(os.environ, PUPPETEER_SKIP_DOWNLOAD="true"),
                                      stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=CNW, text=True, encoding="utf-8", errors="replace")
                for line in pr.stdout:
                    if line.strip(): self.log("npm: " + line.strip()[:160])
                pr.wait()
                self.log("Install finished." if pr.returncode == 0 else f"Install FAILED (code {pr.returncode}) – see lines above.")
            except Exception as e:
                self.log(f"Install failed: {e}")
            self.installing = False
            if self.problem() is None and self.cfg.get("wa_auto", True): self.start()
        threading.Thread(target=go, daemon=True).start()
        return True

    def view(self):
        with self.lock: lines = list(self.lines)[-100:]
        return {"state": self.state, "qr": self.qr, "qr_img": self.qr_img, "number": self.number, "running": self.running(),
                "problem": self.problem(), "installing": self.installing, "log": lines}


# ------------------------------------------------------------------ mirror of the counter queue (Live Queue tab)
class Mirror:
    """Reads the same queue the counter shows (website + WhatsApp + cash) so this window can show / act on every job."""
    def __init__(self, cfg):
        self.cfg = cfg
        self.orders = []; self.flags = {}; self.wa_site = {}; self.stats = {}
        self.ok = False; self.err = ""
        self.stop = threading.Event(); self.wake = threading.Event(); self._st_ts = 0
        self.idle = False                 # window hidden -> poll slowly, skip the revenue stats
        self.on_cash = None               # callback(list_of_new_cash_orders) – used for the tray notification
        self.on_approved = None           # callback() – a job became printable: wake the print agent at once
        self._cash_seen = None; self._appr_seen = None

    def _watch(self):
        cash = {o["id"]: o for o in self.orders if o.get("status") == "cash_wait"}
        appr = {o["id"] for o in self.orders if o.get("status") == "approved"}
        if self._cash_seen is not None:
            new = [o for i, o in cash.items() if i not in self._cash_seen]
            if new and self.on_cash:
                try: self.on_cash(new)
                except Exception: pass
            if (appr - self._appr_seen) and self.on_approved:
                try: self.on_approved()
                except Exception: pass
        self._cash_seen = set(cash); self._appr_seen = appr

    def loop(self):
        while not self.stop.is_set():
            try:
                if self.cfg.get("key"):
                    d = api(self.cfg, "GET", "/api/admin/orders", timeout=20)
                    self.orders, self.flags, self.wa_site = d.get("orders", []), d.get("flags", {}), d.get("wa", {})
                    self._watch()
                    if not self.idle and time.time() - self._st_ts > 15:
                        self.stats = api(self.cfg, "GET", "/api/admin/stats", timeout=20); self._st_ts = time.time()
                    self.ok = True; self.err = ""
            except urllib.error.HTTPError as e:
                self.ok = False; self.err = "Wrong agent key" if e.code in (401, 403) else f"Server error {e.code}"
            except Exception as e:
                self.ok = False; self.err = "No internet / website unreachable"
            self.wake.wait(12 if self.idle else 5); self.wake.clear()


class WebState:
    """What the agent threads report; the web window polls it through Api.get_state()."""
    def __init__(self):
        self.lock = threading.Lock()
        self.lines = deque(maxlen=300)
        self.jobs = {}
        self.conn = ""
        self.on_printers = None

    def log(self, m):
        with self.lock: self.lines.append(time.strftime("%H:%M:%S ") + str(m))

    def job(self, oid, summ, status):
        with self.lock:
            self.jobs[oid] = (summ, status)
            while len(self.jobs) > 60: self.jobs.pop(next(iter(self.jobs)))

    def job_remove(self, oid):
        with self.lock:
            if oid in self.jobs and "Waiting" in self.jobs[oid][1]: del self.jobs[oid]

    def event(self, name, arg=None):
        if name == "conn": self.conn = arg
        elif name == "printers" and self.on_printers: self.on_printers()


ORDER_ACTIONS = {"approve": "approve", "cash": "cash-approve", "reject": "reject", "reprint": "reprint"}
PREFS = {"sound": bool, "theme": ("light", "dark"), "wa_auto": bool, "paper_bw": ("A4", "A3", "A5", "letter", "legal"), "paper_color": ("A4", "A3", "A5", "letter", "legal"),
         "bin_bw": str, "bin_color": str}


class Api:
    """Methods the page can call (window.pywebview.api.*). Attributes start with _ so pywebview does not expose them."""
    def __init__(self, cfg, agent, st, wa, mirror):
        self._cfg, self._agent, self._st, self._wa, self._mirror = cfg, agent, st, wa, mirror
        self._on_quit = None

    def quit_app(self):
        if self._on_quit: self._on_quit()
        return True

    def _on_printers(self):
        a, c = self._agent, self._cfg
        if not a.printers: return
        for k in c["roles"]:
            if not c["roles"].get(k) and k != "a3":
                c["roles"][k] = pick_default(a.printers, photo=(k == "photo")); save_cfg(c)

    def _queue(self):
        with self._st.lock: local = dict(self._st.jobs)
        out = []
        for o in self._mirror.orders:
            files = o.get("files") or []
            out.append({"id": o["id"], "source": o.get("source") or "web", "token": o.get("token") or "", "name": o.get("name") or "",
                        "phone": o.get("wa_number") or o.get("phone") or "", "status": o.get("status") or "", "color": int(o.get("color") or 0),
                        "copies": int(o.get("copies") or 1), "amount": o.get("amount") or 0, "paper": o.get("paper") or "A4",
                        "pages": sum(int(f.get("pages") or 0) for f in files), "pay_status": o.get("pay_status") or "", "pay_method": o.get("pay_method") or "",
                        "created_at": o.get("created_at") or 0, "note": o.get("note") or "", "has_files": bool(files), "local": (local.get(o["id"]) or ("", ""))[1]})
        return out

    def get_state(self):
        a, c, st, m = self._agent, self._cfg, self._st, self._mirror
        with st.lock:
            log = list(st.lines)[-100:]
        return {"conn": st.conn, "sync_text": ago(a.last_ok), "shop": a.shop, "site": c["site"].replace("https://", "").replace("http://", "").rstrip("/"),
                "site_full": c["site"], "key": c["key"], "startup": bool(c["startup"]), "open_counter": bool(c.get("open_counter")),
                "has_key": bool(c["key"]), "paused": a.paused, "photo_fit": c.get("photo_fit") or PHOTO_FIT,
                "counter_url": counter_url(c), "printers": a.printers, "roles": c["roles"], "log": log,
                "queue": self._queue(), "flags": m.flags, "stats": m.stats, "server_ok": m.ok, "server_err": m.err,
                "wa": self._wa.view(), "wa_site": m.wa_site,
                "prefs": {k: c.get(k, DEFAULTS.get(k)) for k in PREFS}}

    # ---- printers / rules (unchanged behaviour)
    def set_role(self, role, name):
        if role in self._cfg["roles"]:
            self._cfg["roles"][role] = name or ""; save_cfg(self._cfg)
        return True

    def toggle_pause(self):
        a = self._agent; a.paused = not a.paused
        if a.paused: self._st.conn = "paused"
        else: a.wake.set()
        return a.paused

    def set_photo_fit(self, v):
        global PHOTO_FIT
        if v in ("contain", "cover"):
            PHOTO_FIT = v; self._cfg["photo_fit"] = v; save_cfg(self._cfg)
        return True

    def save_all(self):
        save_cfg(self._cfg); self._st.log("Settings saved."); return True

    def set_pref(self, key, value):
        rule = PREFS.get(key)
        if rule is None: return False
        if rule is bool: value = bool(value)
        elif rule is str: value = str(value or "").strip()[:3]
        elif value not in rule: return False
        self._cfg[key] = value; save_cfg(self._cfg)
        PRINT_OPTS.update({k: self._cfg.get(k, "") for k in ("paper_bw", "paper_color", "bin_bw", "bin_color", "copies_mode")})
        return True

    def set_flag(self, name, value):
        """Rules that live on the website (shared with counter.html): auto-print of paid orders, WhatsApp bot mode, keep files for reprint."""
        if name not in ("autoprint", "wabot", "keepfiles"): return {"ok": False}
        try:
            d = api(self._cfg, "POST", "/api/admin/settings", {name: value})
            self._mirror.flags = d.get("flags", self._mirror.flags)
            self._st.log({"autoprint": "Auto-print of ONLINE-PAID orders: " + ("ON" if value else "OFF (they wait for your approval)"),
                          "wabot": "WhatsApp bot: " + ("instant B&W (skips the B&W/Color question)" if value == "instant" else "asks B&W / Color first"),
                          "keepfiles": "Keep files for reprint: " + ("ON (30 min)" if value else "OFF")}[name])
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)[:80]}

    def save_settings(self, d):
        c = self._cfg
        old = (c["site"], c["key"])
        site = (d.get("site") or "").strip().rstrip("/")
        if site and not site.lower().startswith("http"): site = "https://" + site
        c["site"] = site or c["site"]; c["key"] = (d.get("key") or "").strip()
        c["open_counter"] = bool(d.get("open_counter"))
        c["wa_auto"] = bool(d.get("wa_auto", c.get("wa_auto", True)))
        want = bool(d.get("startup"))
        if want != c["startup"]:
            c["startup"] = want
            try: apply_startup(c, self._st.log)
            except Exception as e: self._st.log(f"Start-with-Windows failed: {e}")
        save_cfg(c); self._agent.shop = ""; self._agent.wake.set(); self._mirror.wake.set(); self._st.log("Connection saved.")
        if (c["site"], c["key"]) != old and self._wa.running():
            threading.Thread(target=self._wa.reconnect, daemon=True).start()
        elif c["wa_auto"] and c["key"] and not self._wa.running() and self._wa.problem() is None:
            threading.Thread(target=self._wa.start, daemon=True).start()
        chk = check_admin(c)
        if chk == "ok": self._st.log("Agent key is accepted by the website (counter + printing).")
        elif chk == "wrong": self._st.log("Agent key was REJECTED by the website - it must equal AGENT_KEY in Cloudflare.")
        return {"ok": True, "pin": chk}

    def sync_now(self):
        self._agent.wake.set(); self._mirror.wake.set(); self._st.log("Checking for new print jobs..."); return True

    def refresh_printers(self):
        def go():
            self._agent.printers = list_printers(); self._agent.pwake.set(); self._on_printers()
        threading.Thread(target=go, daemon=True).start(); self._st.log("Printer list refreshed."); return True

    def printer_prefs(self, role):
        name = self._cfg["roles"].get(role, "")
        if not name: return {"msg": "Choose a printer first."}
        open_printer_prefs(name); return {"msg": "Opening printer preferences..."}

    def make_queue(self, role=None):
        c = self._cfg
        src = c["roles"].get("color") or c["roles"].get("bw")
        if not src or not IS_WIN: return {"msg": "Choose the A4 printer first (Windows only)."}
        new = create_photo_queue(src)
        self._st.log(f"Creating photo queue: {new}")
        return {"msg": f"Click Yes in the Windows prompt. Then choose '{new}' for 4x6 Photos."}

    def open_poster(self):
        import webbrowser; webbrowser.open(self._cfg["site"].rstrip("/") + "/poster.html"); return True

    def open_counter_browser(self):
        import webbrowser; webbrowser.open(counter_url(self._cfg)); return True

    # ---- the Live Queue buttons
    def order_action(self, oid, action):
        ep = ORDER_ACTIONS.get(action)
        if not ep or not re.fullmatch(r"[A-Z0-9]+", str(oid or "")): return {"ok": False, "error": "bad request"}
        try:
            api(self._cfg, "POST", f"/api/admin/{ep}/{oid}")
            self._st.log({"approve": "Approved & sent to printer", "cash": "💵 Cash received – printing", "reject": "Cancelled", "reprint": "Reprint started"}[action] + f": {oid}")
            self._mirror.wake.set(); self._agent.wake.set()
            return {"ok": True}
        except urllib.error.HTTPError as e:
            try: msg = json.loads(e.read().decode() or "{}").get("error")
            except Exception: msg = None
            return {"ok": False, "error": msg or f"Website said {e.code}"}
        except Exception as e:
            return {"ok": False, "error": str(e)[:80]}

    def preview(self, oid):
        o = next((x for x in self._mirror.orders if x.get("id") == oid), None)
        files = (o or {}).get("files") or []
        if not files: return {"ok": False, "error": "The file is already deleted (privacy) – nothing to preview."}
        try:
            tmp = tempfile.mkdtemp(prefix="preview_")
            safe = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in files[0]["name"]) or "file"
            dest = os.path.join(tmp, safe); download(self._cfg, files[0]["id"], dest)
            tm = threading.Timer(600, shutil.rmtree, args=(tmp,), kwargs={"ignore_errors": True}); tm.daemon = True; tm.start()      # customer file: not left on the PC
            if IS_WIN: os.startfile(dest)
            elif shutil.which("xdg-open"): subprocess.Popen(["xdg-open", dest])
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)[:80]}

    # ---- WhatsApp bot
    def wa_start(self):
        self._cfg["wa_auto"] = True; save_cfg(self._cfg); threading.Thread(target=self._wa.start, daemon=True).start(); return True

    def wa_stop(self):
        self._cfg["wa_auto"] = False; save_cfg(self._cfg); threading.Thread(target=self._wa.stop, daemon=True).start(); return True

    def wa_reconnect(self):
        threading.Thread(target=self._wa.reconnect, daemon=True).start(); return True

    def wa_logout(self):
        threading.Thread(target=self._wa.logout, daemon=True).start(); return True

    def wa_install(self):
        return self._wa.install()

    def wa_folder(self):
        if IS_WIN: os.startfile(app_dir())
        return True

    def open_url(self, url):
        import webbrowser
        if str(url).startswith("https://nodejs.org/"): webbrowser.open(url)
        return True


UI_HTML = r'''<!doctype html>
<html lang="en" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Agent</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<style>
:root{--spring:cubic-bezier(.16,1,.3,1);--brand:#4f5bff;--grad:linear-gradient(135deg,#4f5bff,#8b5cf6 55%,#ff5fa2);--green:#16a34a;--amber:#f59e0b;--red:#dc2626;--blue:#2563eb;
--bg1:#eef2ff;--bg2:#fdf2f8;--bg3:#ecfdf5;--glass:rgba(255,255,255,.88);--glass2:rgba(255,255,255,.9);--line:rgba(99,102,241,.16);--ink:#0f172a;--mute:#64748b;--chip:rgba(79,91,255,.09);--shadow:0 18px 40px -22px rgba(60,70,200,.45);--inp:#fff}
[data-theme=dark]{--bg1:#0a0f22;--bg2:#1a1037;--bg3:#07251f;--glass:rgba(28,34,72,.92);--glass2:rgba(38,45,92,.8);--line:rgba(165,180,255,.17);--ink:#e8ecff;--mute:#9aa7d0;--chip:rgba(165,180,255,.12);--shadow:0 18px 40px -22px rgba(0,0,0,.8);--inp:rgba(255,255,255,.07)}
*{box-sizing:border-box}html,body{height:100%;margin:0}
body{font-family:"Segoe UI",system-ui,sans-serif;color:var(--ink);font-size:14px;display:flex;flex-direction:column;overflow:hidden;background:var(--bg1)}
body:before{content:"";position:fixed;inset:-20%;z-index:-1;background:radial-gradient(40% 35% at 12% 10%,rgba(79,91,255,.28),transparent 70%),radial-gradient(38% 34% at 90% 8%,rgba(255,95,162,.24),transparent 70%),radial-gradient(45% 40% at 55% 105%,rgba(46,230,168,.22),transparent 70%);animation:drift 16s ease-in-out infinite alternate}
@keyframes drift{to{transform:translate3d(2%,-3%,0) scale(1.06)}}
button{font-family:inherit;cursor:pointer;border:0;transition:transform .35s var(--spring),box-shadow .35s var(--spring),filter .2s,background .2s}
button:active{transform:scale(.96)}
.hidden{display:none!important}
.glass{background:var(--glass);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow)}
/* top */
.top{display:flex;align-items:center;gap:10px;padding:10px 18px;flex-wrap:nowrap;white-space:nowrap;margin:10px 12px 0;border-radius:20px;min-width:0}
.top>*{flex:0 0 auto;white-space:nowrap}.top>.sp{flex:1 1 0;min-width:0}.top>.tabs{flex:0 1 auto;min-width:0;overflow:hidden}
.brand{display:flex;align-items:center;gap:11px}
.logo{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;overflow:hidden;flex:none}.logo svg{width:44px;height:44px;display:block}
@keyframes glow{0%,100%{box-shadow:0 0 0 0 rgba(79,91,255,.45)}50%{box-shadow:0 0 0 10px rgba(79,91,255,0)}}
.brand h1{margin:0;font-size:19px;line-height:1.1;background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent}
.brand small{color:var(--mute);font-size:11px;letter-spacing:.3px}@media(max-width:1380px){.brand small{display:none}}
@media(max-width:1260px){.kv{display:none}}
@media(max-width:1120px){.top{gap:6px;padding:10px 12px}.tabs{margin-left:2px;gap:2px}.tab{padding:8px 8px;font-size:12.5px;gap:4px}.chip span{display:none}.ib{width:34px;height:34px}.btn{padding:9px 11px}}
.tabs{display:flex;gap:4px;padding:4px;background:var(--chip);border-radius:15px;margin-left:8px}
.tab{padding:9px 12px;border-radius:12px;background:transparent;color:var(--ink);font-weight:700;font-size:13.5px;position:relative;display:flex;align-items:center;gap:6px}
.tab:hover{background:var(--chip)}
.tab.on{background:var(--grad);color:#fff;box-shadow:0 10px 20px -10px rgba(79,91,255,.9)}
.tab .bd{min-width:19px;height:19px;border-radius:10px;background:var(--amber);color:#fff;font-size:11px;display:inline-flex;align-items:center;justify-content:center;padding:0 5px;animation:ring 1.6s infinite}
.tab .dot{width:9px;height:9px;border-radius:50%;background:#94a3b8}.tab .dot.ok{background:#22c55e}.tab .dot.warn{background:var(--amber)}.tab .dot.bad{background:var(--red)}
.sp{flex:1 1 0}
.chip{display:flex;flex-direction:column;padding:6px 12px;border-radius:13px;background:var(--chip);min-width:0}
.chip b{font-size:13px}.chip span{font-size:10.5px}
.chip.ok{background:rgba(22,163,74,.14);color:var(--green)}.chip.bad{background:rgba(220,38,38,.13);color:var(--red)}.chip.warn{background:rgba(245,158,11,.16);color:#b45309}
[data-theme=dark] .chip.warn{color:#fbbf24}
.kv{display:flex;flex-direction:column}.kv small{color:var(--mute);font-size:10.5px}.kv b{font-size:13px}
.ib{width:38px;height:38px;border-radius:12px;background:var(--chip);color:var(--ink);font-size:17px}.ib:hover{transform:translateY(-2px) rotate(-6deg)}
.btn{white-space:nowrap;padding:9px 15px;border-radius:12px;font-weight:700;font-size:13px;background:var(--chip);color:var(--ink)}
.btn:hover{transform:translateY(-2px);filter:brightness(1.05)}
.btn.pri{background:var(--grad);color:#fff;box-shadow:0 12px 22px -12px rgba(79,91,255,.9)}
.btn.go{background:linear-gradient(135deg,#16a34a,#22c55e);color:#fff;box-shadow:0 12px 22px -12px rgba(22,163,74,.9)}
.btn.warn{background:linear-gradient(135deg,#f59e0b,#fb923c);color:#fff}
.btn.red{background:rgba(220,38,38,.12);color:var(--red)}.btn.red:hover{background:var(--red);color:#fff}
.btn.sm{padding:7px 11px;font-size:12px;border-radius:10px}
/* pages */
main{flex:1;min-height:0;display:flex;flex-direction:column}
.page{flex:1;overflow:auto;padding:12px 14px 14px}
#pCounter{padding:0;display:flex;flex-direction:column;overflow:hidden}
.cbar{display:flex;gap:8px;align-items:center;padding:7px 14px;font-size:12px;color:var(--mute)}
#frame{flex:1;border:0;width:100%;background:#fff;border-radius:0 0 18px 18px}
.fade{animation:up .5s var(--spring)}@keyframes up{from{opacity:0;transform:translateY(14px) scale(.985)}to{opacity:1;transform:none}}
h2{margin:0;font-size:17px}
/* kpi */
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
@media(max-width:1000px){.kpis{grid-template-columns:repeat(2,1fr)}}
.kpi{padding:14px 18px;position:relative;overflow:hidden}
.kpi small{color:var(--mute);font-weight:700;font-size:11px;letter-spacing:.4px;text-transform:uppercase}
.kpi b{display:block;font-size:28px;margin-top:3px;font-variant-numeric:tabular-nums}
.kpi i{position:absolute;right:12px;top:8px;font-size:26px;opacity:.85;font-style:normal}
.kpi.amber{border-color:rgba(245,158,11,.5)}.kpi.amber.hot{animation:ring 1.8s infinite}
.filters{display:flex;gap:6px;margin:12px 0 10px;flex-wrap:wrap}
.fl{padding:7px 14px;border-radius:999px;background:var(--chip);color:var(--ink);font-weight:700;font-size:12.5px}
.fl.on{background:var(--ink);color:var(--bg1)}
/* jobs */
.job{display:grid;grid-template-columns:auto 1fr auto;gap:10px 16px;align-items:center;padding:13px 16px;margin-bottom:10px;transition:transform .4s var(--spring),box-shadow .4s}
.job:hover{transform:translateY(-3px)}
.job.cash{border-color:rgba(245,158,11,.7);background:linear-gradient(135deg,rgba(245,158,11,.16),var(--glass));animation:ring 1.8s infinite}
.src{padding:5px 11px;border-radius:999px;font-size:11.5px;font-weight:800;white-space:nowrap}
.src.web{background:rgba(79,91,255,.14);color:#4f5bff}.src.wa{background:rgba(34,197,94,.17);color:#15803d}.src.ct{background:rgba(139,92,246,.17);color:#7c3aed}
[data-theme=dark] .src.web{color:#a5b4ff}[data-theme=dark] .src.wa{color:#4ade80}[data-theme=dark] .src.ct{color:#c4b5fd}
.tok{font-size:21px;font-weight:900;letter-spacing:1.5px;background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent}
.who{color:var(--mute);font-size:12.5px;margin-top:1px}
.meta{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:6px}
.b{padding:4px 10px;border-radius:999px;font-size:11.5px;font-weight:800;background:var(--chip);white-space:nowrap}
.b.bw{background:#1e293b;color:#fff}.b.col{background:linear-gradient(90deg,#ef4444,#f59e0b,#10b981,#3b82f6,#8b5cf6);color:#fff}
.b.ok{background:rgba(22,163,74,.16);color:var(--green)}.b.amber{background:rgba(245,158,11,.2);color:#b45309}.b.info{background:rgba(37,99,235,.14);color:var(--blue)}.b.bad{background:rgba(220,38,38,.14);color:var(--red)}.b.blue{background:rgba(37,99,235,.16);color:var(--blue)}.b.mute{color:var(--mute)}
[data-theme=dark] .b.amber{color:#fbbf24}[data-theme=dark] .b.info,[data-theme=dark] .b.blue{color:#93c5fd}
.pulse{position:relative;animation:ring 1.8s infinite}
@keyframes ring{0%{box-shadow:0 0 0 0 rgba(245,158,11,.5)}70%{box-shadow:0 0 0 12px rgba(245,158,11,0)}100%{box-shadow:0 0 0 0 rgba(245,158,11,0)}}
.b.blue.pulse,.b.info.pulse{animation-name:ringb}@keyframes ringb{0%{box-shadow:0 0 0 0 rgba(37,99,235,.5)}70%{box-shadow:0 0 0 11px rgba(37,99,235,0)}100%{box-shadow:0 0 0 0 rgba(37,99,235,0)}}
.amt{font-size:22px;font-weight:900;text-align:right}
.acts{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;grid-column:1/-1;border-top:1px dashed var(--line);padding-top:10px}
.cashbtn{font-size:15px;padding:11px 20px;flex:1 1 260px;max-width:420px}
.empty{text-align:center;padding:46px 10px;color:var(--mute)}.empty big{display:block;font-size:44px;animation:float 3s ease-in-out infinite}
@keyframes float{50%{transform:translateY(-8px)}}
/* wa */
.g2{display:grid;grid-template-columns:minmax(300px,420px) 1fr;gap:14px}
@media(max-width:980px){.g2{grid-template-columns:1fr}}
.card{padding:18px}
.stat{display:flex;align-items:center;gap:12px;padding:14px;border-radius:16px;background:var(--chip);margin:10px 0}
.stat .led{width:16px;height:16px;border-radius:50%;background:#94a3b8}.stat .led.ok{background:#22c55e;animation:ringg 1.8s infinite}.stat .led.warn{background:var(--amber);animation:ring 1.8s infinite}.stat .led.bad{background:var(--red)}
@keyframes ringg{0%{box-shadow:0 0 0 0 rgba(34,197,94,.55)}70%{box-shadow:0 0 0 12px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
.qrbox{display:flex;flex-direction:column;align-items:center;gap:10px;padding:16px;border-radius:18px;background:#fff;color:#0f172a;position:relative;overflow:hidden;margin:10px 0}
.qrbox:after{content:"";position:absolute;left:0;right:0;height:46px;top:-46px;background:linear-gradient(180deg,transparent,rgba(79,91,255,.35),transparent);animation:scan 2.4s linear infinite}
@keyframes scan{to{top:100%}}
#qrDraw img,#qrDraw canvas{display:block}
.steps{margin:6px 0 0;padding-left:20px;line-height:1.7;color:var(--mute)}
.steps b{color:var(--ink)}
#waLog,#log{font-family:Consolas,monospace;font-size:12px;background:#0b1020;color:#cbd5e1;border-radius:12px;padding:10px;height:170px;overflow:auto;white-space:pre-wrap}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
/* rules + printers */
.rule{display:flex;align-items:center;gap:14px;padding:13px 16px;border-radius:16px;background:var(--chip);margin-top:10px}
.rule .t{flex:1}.rule .t b{display:block;font-size:14.5px}.rule .t small{color:var(--mute);font-size:12px}
.rule.lock{border:1px dashed rgba(245,158,11,.6);background:rgba(245,158,11,.1)}
.sw{width:52px;height:28px;border-radius:14px;background:#94a3b8;position:relative;cursor:pointer;flex-shrink:0;transition:background .3s}
.sw:after{content:"";position:absolute;top:3px;left:3px;width:22px;height:22px;border-radius:50%;background:#fff;transition:transform .45s var(--spring);box-shadow:0 2px 6px rgba(0,0,0,.3)}
.sw.on{background:var(--green)}.sw.on:after{transform:translateX(24px)}
.seg{display:inline-flex;background:var(--chip);border-radius:12px;padding:3px}
.seg button{padding:7px 12px;border-radius:9px;background:transparent;color:var(--ink);font-size:12.5px;font-weight:700}
.seg button.on{background:var(--glass2);box-shadow:0 2px 8px rgba(0,0,0,.18)}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:12px}
@media(max-width:1100px){.grid{grid-template-columns:repeat(2,1fr)}}
.pc{border:1px solid var(--line);border-radius:18px;padding:13px;display:flex;flex-direction:column;background:var(--glass2);transition:transform .4s var(--spring)}
.pc:hover{transform:translateY(-4px)}
.pc .ic{font-size:28px}.pc h3{margin:2px 0 0;font-size:15px}.pc .sub{color:var(--mute);font-size:11.5px;margin-bottom:9px}
select,input[type=text],input[type=password]{width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:11px;font-family:inherit;font-size:13px;background:var(--inp);color:var(--ink)}
select option{color:#0f172a}
.pc hr{border:0;border-top:1px solid var(--line);margin:9px 0;width:100%}
.pc label{display:flex;gap:7px;align-items:center;padding:2px 0;font-size:12.5px}
.pc .two{display:grid;grid-template-columns:1fr 70px;gap:6px;margin-top:4px}
.mini{width:100%;margin-top:6px;padding:7px;border-radius:9px;background:var(--chip);font-weight:700;font-size:12px;color:var(--ink)}
.pill{margin-top:9px;padding:8px;border-radius:10px;font-weight:700;font-size:12.5px;background:var(--chip);color:var(--mute);text-align:center}
.pill.ok{background:rgba(22,163,74,.15);color:var(--green)}.pill.bad{background:rgba(220,38,38,.13);color:var(--red)}.pill.warn{background:rgba(245,158,11,.16);color:#b45309}.pill.info{background:rgba(37,99,235,.14);color:var(--blue)}
.pause{display:block;width:100%;margin-top:12px;padding:12px;border-radius:14px;background:linear-gradient(135deg,#f59e0b,#fb923c);color:#fff;font-size:14.5px;font-weight:700}.pause.on{background:linear-gradient(135deg,#16a34a,#22c55e)}
footer{margin:0 12px 10px;padding:7px 16px;display:flex;font-size:11.5px;color:var(--mute);gap:8px;flex-wrap:wrap;border-radius:14px}
footer b{color:var(--green)}footer .r{margin-left:auto;font-weight:700}
.ov{position:fixed;inset:0;background:rgba(8,12,30,.6);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;z-index:50}
.modal{background:var(--glass2);color:var(--ink);border:1px solid var(--line);border-radius:22px;padding:22px;width:min(94vw,500px);animation:up .45s var(--spring)}
.modal h3{margin:0 0 4px;font-size:19px}.modal p{margin:0 0 10px;color:var(--mute);font-size:12.5px}
.modal label.l{display:block;font-weight:700;font-size:13px;margin:10px 0 3px}
.modal .chk{display:flex;gap:8px;align-items:center;margin-top:10px;font-size:13px}
.toast{position:fixed;bottom:50px;left:50%;transform:translateX(-50%);background:#0f172a;color:#fff;padding:10px 20px;border-radius:12px;font-size:13px;z-index:60;animation:up .35s var(--spring);max-width:80vw}
.alert{position:fixed;top:78px;right:22px;z-index:70;background:linear-gradient(135deg,#f59e0b,#fb923c);color:#fff;padding:14px 20px;border-radius:16px;font-weight:800;box-shadow:0 18px 40px -12px rgba(245,158,11,.8);animation:up .45s var(--spring)}
.alert small{display:block;font-weight:600;opacity:.95}
/* ===== low-CPU mode: no blur, no infinite repaints; everything stops while the window is hidden ===== */
body:before{animation:none!important;inset:0!important}
.glass,.modal,.chip,.kpi,.card,.pc,.job{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
.logo,.tab .bd,.kpi.amber.hot,.job.cash,.pulse,.b.blue.pulse,.b.info.pulse,.stat .led.ok,.stat .led.warn,.empty big,.qrbox:after{animation:none!important}
.pulse:before,.tab .bd:before{content:"";display:inline-block;width:7px;height:7px;border-radius:50%;background:currentColor;margin-right:5px;vertical-align:1px;animation:dotP 1.4s ease-in-out infinite}
.tab .bd:before{display:none}
@keyframes dotP{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(.5);opacity:.3}}
.job.still{animation:none}
html.paused *,html.paused *:before,html.paused *:after{animation:none!important;transition:none!important}
</style></head><body>
<div class="top glass">
  <div class="brand"><div class="logo">%%LOGO_SVG%%</div><div><h1>Agent</h1><small>therajesh.shop · Web + WhatsApp + Cash</small></div></div>
  <div class="tabs">
    <button class="tab on" data-t="queue">📋 Live Queue <span class="bd hidden" id="bdCash">0</span></button>
    <button class="tab" data-t="wa">💬 WhatsApp <span class="dot" id="waDot"></span></button>
    <button class="tab" data-t="rules">🖨 Printers &amp; Rules</button>
    <button class="tab" data-t="counter">🖥 Counter</button>
  </div>
  <div class="sp"></div>
  <div class="kv"><small>Last Sync</small><b id="sync">—</b></div>
  <div class="chip" id="chip"><b id="chipT">● Starting…</b><span id="chipS">Please wait</span></div>
  <button class="ib" id="bSound" title="Sound alerts">🔔</button>
  <button class="ib" id="bTheme" title="Dark / light">🌙</button>
  <button class="btn" id="bSettings">⚙ Settings</button>
</div>
<main>
 <!-- ============ TAB 1: LIVE QUEUE ============ -->
 <div class="page" id="pQueue">
  <div class="kpis">
    <div class="kpi glass"><i>📲</i><small>Today's UPI collection</small><b id="kUpi">₹0</b></div>
    <div class="kpi glass"><i>💵</i><small>Today's cash collection</small><b id="kCash">₹0</b></div>
    <div class="kpi glass"><i>📄</i><small>Pages printed today</small><b id="kPages">0</b></div>
    <div class="kpi glass amber" id="kPendBox"><i>⏳</i><small>Cash waiting approval</small><b id="kPend">0</b></div>
  </div>
  <div class="filters" id="filters"></div>
  <div id="jobs"></div>
 </div>
 <!-- ============ TAB 2: WHATSAPP ============ -->
 <div class="page hidden" id="pWa">
  <div class="g2">
   <div class="card glass fade">
     <h2>💬 WhatsApp Bot &amp; Connection</h2>
     <div class="stat"><div class="led" id="waLed"></div><div><b id="waT">—</b><div id="waS" style="color:var(--mute);font-size:12px"></div></div></div>
     <div id="waQrWrap" class="hidden"><div class="qrbox"><div id="qrDraw"></div><b style="font-size:13px">📱 Scan with the shop phone</b></div>
       <ol class="steps"><li>Open <b>WhatsApp</b> on the shop phone</li><li><b>Settings → Linked devices → Link a device</b></li><li>Point the camera at this QR code</li></ol></div>
     <div id="waProb" class="hidden"></div>
     <div class="row" style="margin-top:12px" id="waBtns"></div>
   </div>
   <div class="card glass fade">
     <h2>🧾 How a customer order flows</h2>
     <ol class="steps"><li>Customer sends a PDF / photo on WhatsApp</li><li>Bot asks <b>1 B&amp;W</b> or <b>2 Color</b> (<b>1x3</b> = 3 copies)</li><li>Bot asks <b>1 UPI QR</b> or <b>2 Cash</b></li><li>UPI paid → <b>prints automatically</b> (if the rule is ON)</li><li>Cash → waits for <b>✅ Cash Received — Print Now</b></li></ol>
     <h2 style="margin-top:14px">📜 Bot log</h2>
     <div id="waLog" style="margin-top:8px"></div>
   </div>
  </div>
 </div>
 <!-- ============ TAB 3: PRINTERS & RULES ============ -->
 <div class="page hidden" id="pRules">
  <div class="card glass fade">
    <h2>⚡ Smart Auto-Print Rules</h2>
    <div class="rule"><div class="t"><b>✅ Auto-Print Online Paid Orders (UPI / Razorpay)</b><small>ON: prints the moment the payment succeeds · OFF: paid orders wait for your approval</small></div><div class="sw" id="swAuto"></div></div>
    <div class="rule lock"><div class="t"><b>💵 Cash Orders — never auto-print</b><small>Always held until you click “✅ Cash Received — Print Now” here or in the Counter</small></div><div style="font-size:24px">🔒</div></div>
    <div class="rule"><div class="t"><b>💬 WhatsApp bot mode</b><small>What happens when a file arrives</small></div><div class="seg" id="segBot"><button data-v="ask">Ask B&amp;W / Color</button><button data-v="instant">Instant B&amp;W</button></div></div>
    <div class="rule"><div class="t"><b>🔄 Keep files 30 min for Reprint</b><small>OFF: files are deleted right after printing (more private)</small></div><div class="sw" id="swKeep"></div></div>
    <div class="rule"><div class="t"><b>🔔 Sound alerts</b><small>Beep for new WhatsApp / cash requests</small></div><div class="sw" id="swSound"></div></div>
  </div>
  <div class="card glass fade" style="margin-top:12px">
    <h2>🖨 Printer Hardware</h2><div style="color:var(--mute);font-size:12.5px">Choose the printer, paper size and tray for each type of job</div>
    <div class="grid" id="grid"></div>
    <div class="row" style="margin-top:12px"><button class="btn pri" id="bSave">💾 Save Settings</button><button class="btn go" id="bSync">🔄 Sync Now</button><button class="btn" id="bRef">📋 Refresh Printer List</button><button class="btn" id="bPoster">⬇ Open QR Poster</button></div>
    <button class="pause" id="bPause">⏸ Pause Printing</button>
  </div>
  <div class="card glass fade" style="margin-top:12px"><h2>📜 Activity log</h2><div id="log" style="margin-top:8px"></div></div>
 </div>
 <!-- ============ COUNTER ============ -->
 <div class="page glass hidden" id="pCounter" style="margin:12px 14px 14px;padding:0">
  <div class="cbar"><span id="cstat">Loading counter…</span><span class="sp"></span><button class="btn sm" id="bReload">↻ Reload</button><button class="btn sm" id="bBrowser">Open in browser</button></div>
  <iframe id="frame" title="Counter"></iframe>
 </div>
</main>
<footer class="glass"><b>🔒 PRIVACY BY DESIGN</b><span>Files are deleted automatically after printing</span><span>· Minimizes to System Tray on close · Auto-printing &amp; WhatsApp bot stay active</span><span class="r">🌐 therajesh.shop</span></footer>

<div class="ov hidden" id="ov"><div class="modal">
  <h3>Connection settings</h3><p>The agent key must match AGENT_KEY in Cloudflare.</p>
  <label class="l">Website</label><input type="text" id="fSite">
  <label class="l">Agent key</label><input type="password" id="fKey">
  <label class="chk"><input type="checkbox" id="fWa"> Start the WhatsApp bot automatically with this app</label>
  <label class="chk"><input type="checkbox" id="fOpen"> Show the Counter tab when the agent starts</label>
  <label class="chk"><input type="checkbox" id="fStart"> Start automatically with Windows (Auto-Startup)</label>
  <div class="row" style="justify-content:space-between;margin-top:16px"><button class="btn red" id="fQuit" title="Stops printing and the WhatsApp bot">⏻ Quit Agent Completely</button><span class="row"><button class="btn" id="fCancel">Cancel</button><button class="btn pri" id="fSaveBtn">Save</button></span></div>
</div></div>
<div class="toast hidden" id="toast"></div>
<div id="alerts"></div>

<script>
const $=id=>document.getElementById(id);
const A=()=>window.pywebview&&window.pywebview.api;
let S=null,tab="queue",filter="all",namesKey="",counterLoaded="",firstState=true,seen=null,lastHtml={},actx=null;
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
function toast(m){const t=$("toast");t.textContent=m;t.classList.remove("hidden");clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.add("hidden"),2600)}
async function call(fn,...a){try{const r=await A()[fn](...a);await refresh();return r}catch(e){toast("Error: "+(e&&e.message||e))}}
function setTxt(el,key,t){if(lastHtml[key]!==t){lastHtml[key]=t;el.textContent=t}}
let seenJobs=new Set();
function setHtml(el,key,html){if(lastHtml[key]!==html){lastHtml[key]=html;el.innerHTML=html}}
function animNum(el,to,fmt){const from=el._v==null?0:el._v;if(from===to){el.textContent=fmt(to);return}el._v=to;const t0=performance.now();
  (function s(t){const k=Math.min(1,(t-t0)/700),e=1-Math.pow(1-k,3);el.textContent=fmt(from+(to-from)*e);if(k<1)requestAnimationFrame(s)})(t0)}
const rs=n=>"₹"+Math.round(n).toLocaleString("en-IN");
function beep(){if(!S||!S.prefs.sound)return;try{actx=actx||new(window.AudioContext||window.webkitAudioContext)();if(actx.state==="suspended")actx.resume();
  [[880,0],[1175,.22],[1480,.44]].forEach(([f,t])=>{const o=actx.createOscillator(),g=actx.createGain();o.connect(g);g.connect(actx.destination);o.frequency.value=f;g.gain.value=.22;o.start(actx.currentTime+t);o.stop(actx.currentTime+t+.17)})}catch(e){}}
document.addEventListener("click",()=>{try{if(actx&&actx.state==="suspended")actx.resume()}catch(e){}},{once:true});
function popAlert(t,s){const d=document.createElement("div");d.className="alert";d.innerHTML=esc(t)+"<small>"+esc(s||"")+"</small>";$("alerts").appendChild(d);setTimeout(()=>d.remove(),6500)}

/* ---------- tabs ---------- */
function showTab(t){tab=t;["queue","wa","rules","counter"].forEach(k=>{$("p"+{queue:"Queue",wa:"Wa",rules:"Rules",counter:"Counter"}[k]).classList.toggle("hidden",k!==t)});
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("on",b.dataset.t===t));
  if(t==="counter"){if(S)loadCounter(false)}else if(counterLoaded){counterLoaded="";$("frame").src="about:blank"}   /* the Counter page only runs while its tab is open */
  if(S)render()}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>showTab(b.dataset.t));
function loadCounter(force){if(!S)return;const u=S.counter_url;if(force||counterLoaded!==u){counterLoaded=u;$("cstat").textContent="Loading counter…";$("frame").src=u}}
$("frame").onload=()=>{$("cstat").textContent="Counter · "+(S?S.site:"")};
$("bReload").onclick=()=>loadCounter(true);$("bBrowser").onclick=()=>call("open_counter_browser");

/* ---------- live queue ---------- */
const FILTERS=[["all","All"],["web","🌐 Web"],["whatsapp","💬 WhatsApp"],["cash","💵 Cash pending"],["active","🖨 Printing"]];
$("filters").innerHTML=FILTERS.map(([k,l])=>`<button class="fl" data-f="${k}">${l}</button>`).join("");
$("filters").onclick=e=>{const b=e.target.closest("[data-f]");if(b){filter=b.dataset.f;if(S)renderQueue()}};
const STAT={wa_wait:["Choosing B&W / Color","info"],pay_choose:["Choosing payment","info"],pay_wait:["Waiting for UPI","info pulse"],cash_wait:["💵 Cash Pending","amber pulse"],pending:["Waiting approval","amber"],approved:["Printing…","blue pulse"],printing:["Printing…","blue pulse"],printed:["Printed","ok"],error:["Failed","bad"],rejected:["Cancelled","mute"]};
function payBadge(o){if(o.pay_status==="paid")return["✅ Paid via UPI","ok"];if(o.status==="cash_wait")return["💵 Cash - Waiting Approval","amber pulse"];
  if(o.pay_status==="cash_received")return["💵 Cash received","ok"];if(o.pay_status==="free")return["🎁 No charge","info"];if(o.status==="pay_wait")return["⏳ Unpaid","mute"];return["⏳ Unpaid","mute"]}
function actions(o){const a=[],f=o.has_files;
  if(o.status==="cash_wait")a.push(["✅ Cash Received — Print Now","cash","go cashbtn"]);
  else if(o.status==="pay_wait")a.push(["💵 Took cash instead — Print","cash","warn"]);
  else if(["wa_wait","pay_choose"].includes(o.status))a.push(["💵 Cash Received — Print Now","cash","warn"]);
  else if(["pending","error"].includes(o.status))a.push([o.status==="error"?"🔁 Retry Print":"🖨️ Approve & Print","approve","go"]);
  if(f&&!["rejected"].includes(o.status))a.push(["👁️ Preview","preview",""]);
  if(["printed","error"].includes(o.status)&&f)a.push(["🔄 Reprint","reprint",""]);
  if(["wa_wait","pay_choose","pay_wait","cash_wait","pending","error","approved"].includes(o.status))a.push(["🗑️ Cancel","reject","red"]);
  return a}
const ago=ms=>{const s=Math.max(0,(Date.now()-ms)/1000);return s<60?"just now":s<3600?Math.floor(s/60)+" min ago":Math.floor(s/3600)+" h ago"};
function renderQueue(){
  const q=S.queue.slice(),rank=o=>o.status==="cash_wait"?0:["pending","pay_wait","pay_choose","wa_wait","error"].includes(o.status)?1:["approved","printing"].includes(o.status)?2:3;
  q.sort((a,b)=>rank(a)-rank(b)||b.created_at-a.created_at);
  const pend=q.filter(o=>o.status==="cash_wait").length,st=S.stats||{};
  animNum($("kUpi"),(st.upi&&st.upi.amount)||0,rs);animNum($("kCash"),(st.cash&&st.cash.amount)||0,rs);animNum($("kPages"),st.pages||0,n=>Math.round(n).toLocaleString("en-IN"));animNum($("kPend"),pend,n=>Math.round(n));
  $("kPendBox").classList.toggle("hot",pend>0);
  const bd=$("bdCash");bd.textContent=pend;bd.classList.toggle("hidden",!pend);
  setHtml($("filters"),"flt",FILTERS.map(([k,l])=>`<button class="fl ${filter===k?"on":""}" data-f="${k}">${l}${k==="cash"&&pend?` (${pend})`:""}</button>`).join(""));
  const list=q.filter(o=>filter==="all"||(filter==="web"&&o.source==="web")||(filter==="whatsapp"&&o.source==="whatsapp")||(filter==="cash"&&o.status==="cash_wait")||(filter==="active"&&["approved","printing"].includes(o.status)));
  if(!S.has_key)return setHtml($("jobs"),"jobs",`<div class="empty glass"><big>🔑</big>Enter your Agent key in ⚙ Settings to start.</div>`);
  if(!list.length)return setHtml($("jobs"),"jobs",`<div class="empty glass"><big>${S.server_ok?"🌤️":"📡"}</big>${S.server_ok?"No print jobs here yet. New website, WhatsApp and cash orders appear instantly.":esc(S.server_err||"Connecting…")}</div>`);
  setHtml($("jobs"),"jobs",list.map(o=>{const src=o.source==="whatsapp"?["💬 WhatsApp","wa"]:o.source==="counter"?["🖥 Counter","ct"]:["🌐 Web","web"],sb=STAT[o.status]||[o.status,"mute"],pb=payBadge(o);
    return `<div class="job glass ${seenJobs.has(o.id)?"still":"fade"} ${o.status==="cash_wait"?"cash":""}">
      <span class="src ${src[1]}">${src[0]}</span>
      <div><div class="tok">${o.token?"#"+esc(o.token):esc(o.id)}</div><div class="who">${esc(o.name||"Customer")}${o.phone?" · 📞 +"+esc(o.phone.replace(/^\+/,"")):""} · 🕒 ${ago(o.created_at)}</div>
       <div class="meta"><span class="b">📄 ${o.pages||"–"} pg × ${o.copies}</span><span class="b ${o.color?"col":"bw"}">${o.color?"🌈 Color":"⚫ B&W"}</span><span class="b">${esc(o.paper)}</span><span class="b ${pb[1]}">${pb[0]}</span><span class="b ${sb[1]}">${o.status==="cash_wait"?"💵 Cash Pending: "+rs(o.amount):sb[0]}</span>${o.local&&!["approved","printing"].includes(o.status)?`<span class="b mute">${esc(o.local)}</span>`:""}${o.note?`<span class="b bad">${esc(o.note)}</span>`:""}</div></div>
      <div class="amt">${rs(o.amount)}</div>
      <div class="acts">${actions(o).map(([l,a,c])=>`<button class="btn ${c}" data-a="${a}" data-id="${esc(o.id)}">${l}</button>`).join("")}</div></div>`}).join(""));
}
$("jobs").onclick=async e=>{const b=e.target.closest("[data-a]");if(!b)return;const id=b.dataset.id,a=b.dataset.a;
  if(a==="reject"&&!confirm("Cancel this order and delete the file?"))return;
  b.disabled=true;const r=await call(a==="preview"?"preview":"order_action",...(a==="preview"?[id]:[id,a]));
  if(r&&r.ok===false){toast("⚠ "+(r.error||"Failed"));b.disabled=false}else if(a!=="preview")toast({cash:"💵 Cash received – printing",approve:"🖨️ Sent to printer",reject:"Cancelled",reprint:"🔄 Reprint started"}[a])};
function notifyNew(){
  const cur={};S.queue.forEach(o=>cur[o.id]=o.status);
  if(seen){let hit=null;S.queue.forEach(o=>{const was=seen[o.id];
    if(was===undefined&&["wa_wait","pay_choose","cash_wait","pending","approved"].includes(o.status)&&o.source!=="counter")hit=hit||[o.source==="whatsapp"?"💬 New WhatsApp file":"🌐 New print job",(o.name||"Customer")];
    if(o.status==="cash_wait"&&was!==undefined&&was!=="cash_wait")hit=["💵 Cash Pending: "+rs(o.amount),"Token #"+o.token+" is waiting for you"];
    if(o.status==="cash_wait"&&was===undefined)hit=["💵 Cash Pending: "+rs(o.amount),"Token #"+o.token+" is waiting for you"]});
    if(hit){beep();popAlert(hit[0],hit[1])}}
  seen=cur}

/* ---------- whatsapp tab ---------- */
const WA_TXT={ready:["ok","🟢 Connected"],qr:["warn","🟡 Scan the QR code"],authenticated:["warn","🟡 Logging in…"],starting:["warn","🟡 Starting…"],disconnected:["bad","🔴 Disconnected – reconnecting"],error:["bad","🔴 Problem – see the log"],stopped:["bad","⚪ Stopped"]};
function renderWa(){
  const w=S.wa,p=w.problem;let cls="bad",t="⚪ Stopped",sub="";
  if(w.installing){cls="warn";t="🟡 Installing WhatsApp parts…";sub="This takes a few minutes. Keep the window open."}
  else if(p){t={no_node:"🔴 Node.js is not installed",no_modules:"🔴 WhatsApp parts are not installed yet",no_script:"🔴 local-print-server.js is missing",no_key:"🔴 Enter the Agent key first"}[p];}
  else{const x=WA_TXT[w.state]||WA_TXT.stopped;cls=x[0];t=x[1];if(w.state==="ready")sub=w.number?"Connected: +"+w.number:"";if(w.state==="qr")sub="Open WhatsApp ▸ Linked devices ▸ Link a device"}
  $("waLed").className="led "+cls;$("waT").textContent=t;$("waS").textContent=sub;
  $("waDot").className="dot "+(w.state==="ready"?"ok":w.state==="qr"||w.installing?"warn":"bad");
  const showQr=!p&&w.state==="qr";$("waQrWrap").classList.toggle("hidden",!showQr);
  if(showQr&&$("qrDraw")._q!==w.qr){$("qrDraw")._q=w.qr;const d=$("qrDraw");d.innerHTML="";
    if(w.qr_img){const i=document.createElement("img");i.src=w.qr_img;i.width=260;i.height=260;d.appendChild(i)}else if(window.QRCode)new QRCode(d,{text:w.qr,width:260,height:260,correctLevel:QRCode.CorrectLevel.L});else d.textContent="QR library could not load (internet?)"}
  const pr=$("waProb");pr.classList.toggle("hidden",!p);
  if(p)pr.innerHTML={no_node:`<p>The WhatsApp bot needs <b>Node.js</b> (free).</p><button class="btn pri" data-w="node">⬇ Download Node.js</button>`,
    no_modules:`<p>One-time setup: install the WhatsApp parts (needs internet and Google Chrome or Microsoft Edge on this PC).</p><button class="btn pri" data-w="install">📦 Install WhatsApp parts</button>`,
    no_script:`<p>Put <b>local-print-server.js</b> and <b>package.json</b> in the same folder as this app.</p><button class="btn" data-w="folder">📂 Open app folder</button>`,no_key:`<p>Open ⚙ Settings and enter the Agent key.</p>`}[p]||"";
  setHtml($("waBtns"),"wab",p?"":(w.running?`<button class="btn" data-w="reconnect">🔄 Reconnect</button><button class="btn red" data-w="logout">🚪 Logout / Unlink</button><button class="btn" data-w="stop">⏹ Stop</button>`:`<button class="btn go" data-w="start">▶ Start WhatsApp bot</button>`));
  const lg=$("waLog"),end=lg.scrollTop+lg.clientHeight>=lg.scrollHeight-30;setTxt(lg,"waLog",w.log.slice(-100).join("\n")||"Nothing yet.");if(end)lg.scrollTop=1e9}
$("pWa").onclick=async e=>{const b=e.target.closest("[data-w]");if(!b)return;const k=b.dataset.w;
  if(k==="logout"&&!confirm("Unlink this WhatsApp number from the shop PC?\nYou will have to scan a new QR code."))return;
  const fn={node:()=>call("open_url","https://nodejs.org/en/download"),install:()=>call("wa_install"),folder:()=>call("wa_folder"),reconnect:()=>call("wa_reconnect"),logout:()=>call("wa_logout"),stop:()=>call("wa_stop"),start:()=>call("wa_start")}[k];if(fn)fn()};

/* ---------- printers & rules ---------- */
const ROLES=[["bw","1","🖨","Black & White","A4 documents"],["color","2","🎨","Color Printer","A4 color prints"],["photo","3","🖼","4 × 6 Photo","Photo prints"],["a3","4","📄","A3 (optional)","A3 prints"]];
const PAPERS=["A4","A3","A5","letter","legal"];
ROLES.forEach(([k,n,ic,t,sub])=>{const d=document.createElement("div");d.className="pc";
  const extra=k==="photo"?`<label><input type="radio" name="fit" value="contain"> Whole photo (no crop)</label><label><input type="radio" name="fit" value="cover"> Fill 4×6 (crop edges)</label><button class="mini" data-act="prefs">⚙ Photo quality…</button><button class="mini" data-act="queue">＋ Create photo queue</button>`
   :k==="a3"?`<button class="mini" data-act="prefs">⚙ Printer preferences…</button>`
   :`<div class="two"><select id="pap_${k}">${PAPERS.map(p=>`<option>${p}</option>`).join("")}</select><input type="text" id="bin_${k}" placeholder="Tray" maxlength="2" title="Paper tray number (optional)"></div><button class="mini" data-act="prefs">⚙ Printer preferences…</button>`;
  d.innerHTML=`<div class="ic">${ic}</div><h3>${t}</h3><div class="sub">${sub}</div><select id="sel_${k}"></select><hr>${extra}<div class="pill" id="pill_${k}">Select a printer</div>`;
  $("grid").appendChild(d);d.querySelector("select").onchange=e=>call("set_role",k,e.target.value);
  d.querySelectorAll("[data-act]").forEach(b=>b.onclick=async()=>{const r=await call(b.dataset.act==="prefs"?"printer_prefs":"make_queue",k);if(r&&r.msg)toast(r.msg)});
  const pp=d.querySelector("#pap_"+k);if(pp)pp.onchange=e=>call("set_pref","paper_"+k,e.target.value);
  const bb=d.querySelector("#bin_"+k);if(bb)bb.onchange=e=>call("set_pref","bin_"+k,e.target.value)});
document.querySelectorAll("input[name=fit]").forEach(r=>r.onchange=e=>call("set_photo_fit",e.target.value));
$("swAuto").onclick=()=>call("set_flag","autoprint",!(S.flags&&S.flags.autoprint));
$("swKeep").onclick=()=>call("set_flag","keepfiles",!(S.flags&&S.flags.keepfiles));
$("swSound").onclick=()=>call("set_pref","sound",!S.prefs.sound);
$("segBot").onclick=e=>{const b=e.target.closest("[data-v]");if(b)call("set_flag","wabot",b.dataset.v)};
$("bSave").onclick=async()=>{await call("save_all");toast("✔ Settings saved")};
$("bSync").onclick=async()=>{await call("sync_now");toast("Checking for new print jobs…")};
$("bRef").onclick=async()=>{await call("refresh_printers");toast("Printer list refreshed")};
$("bPoster").onclick=()=>call("open_poster");
$("bPause").onclick=()=>call("toggle_pause");
const STATE_UI={Online:["● Printer Ready","ok"],Printing:["● Printing…","info"],Offline:["● Printer Offline","bad"],Error:["● Printer Error","warn"]};
function renderRules(){
  const f=S.flags||{};$("swAuto").classList.toggle("on",f.autoprint!==false);$("swKeep").classList.toggle("on",!!f.keepfiles);$("swSound").classList.toggle("on",!!S.prefs.sound);
  document.querySelectorAll("#segBot button").forEach(b=>b.classList.toggle("on",b.dataset.v===(f.wabot||"ask")));
  $("bPause").textContent=S.paused?"▶ Resume Printing":"⏸ Pause Printing";$("bPause").classList.toggle("on",S.paused);
  const nk=S.printers.map(p=>p.name).join("|"),by={};S.printers.forEach(p=>by[p.name]=p.state);
  ROLES.forEach(([k])=>{const sel=$("sel_"+k);
    if(nk!==namesKey||sel.options.length===0)sel.innerHTML=(k==="a3"?'<option value=""></option>':"")+S.printers.map(p=>`<option>${esc(p.name)}</option>`).join("");
    if(document.activeElement!==sel)sel.value=S.roles[k]||"";
    const pp=$("pap_"+k);if(pp&&document.activeElement!==pp)pp.value=S.prefs["paper_"+k]||"A4";const bb=$("bin_"+k);if(bb&&document.activeElement!==bb)bb.value=S.prefs["bin_"+k]||"";
    const name=S.roles[k],st=by[name],pill=$("pill_"+k);
    if(!name){pill.textContent="Select a printer";pill.className="pill"}else if(!st){pill.textContent="● Printer not found";pill.className="pill bad"}else{const u=STATE_UI[st]||["● "+st,""];pill.textContent=u[0];pill.className="pill "+u[1]}});
  namesKey=nk;document.querySelectorAll("input[name=fit]").forEach(r=>r.checked=(r.value===S.photo_fit));
  const lg=$("log"),end=lg.scrollTop+lg.clientHeight>=lg.scrollHeight-30;setTxt(lg,"log",S.log.slice(-100).join("\n"));if(end)lg.scrollTop=1e9}

/* ---------- header / theme / settings ---------- */
$("bTheme").onclick=()=>call("set_pref","theme",S.prefs.theme==="dark"?"light":"dark");
$("bSound").onclick=()=>call("set_pref","sound",!S.prefs.sound);
$("bSettings").onclick=()=>{$("fSite").value=S.site_full;$("fKey").value=S.key;$("fOpen").checked=S.open_counter;$("fStart").checked=S.startup;$("fWa").checked=S.prefs.wa_auto!==false;$("ov").classList.remove("hidden")};
$("fCancel").onclick=()=>$("ov").classList.add("hidden");
$("fQuit").onclick=()=>{if(confirm("Quit completely?\nPrinting and the WhatsApp bot will stop."))A().quit_app()};
$("fSaveBtn").onclick=async()=>{const r=await call("save_settings",{site:$("fSite").value,key:$("fKey").value,open_counter:$("fOpen").checked,startup:$("fStart").checked,wa_auto:$("fWa").checked});$("ov").classList.add("hidden");counterLoaded="";if(tab==="counter")loadCounter(true);
  const p=r&&r.pin;toast(p==="wrong"?"⚠ Saved, but the website REJECTED this Agent key – it must equal AGENT_KEY in Cloudflare":p==="ok"?"✔ Saved – Agent key is correct":p==="offline"?"Saved (website unreachable, key not checked)":"Connection saved")};
function render(){
  document.documentElement.dataset.theme=S.prefs.theme||"light";$("bTheme").textContent=S.prefs.theme==="dark"?"☀️":"🌙";$("bSound").textContent=S.prefs.sound?"🔔":"🔕";
  const c=S.conn,m={ok:["● Agent Online","Connected & ready","ok"],badkey:["● Wrong Agent Key","Open Settings and fix the key","bad"],offline:["● Offline","No internet / website unreachable","bad"],paused:["● Paused","Printing is on hold","warn"]}[c]||["● Starting…","Please wait",""];
  $("chip").className="chip "+m[2];$("chipT").textContent=m[0];$("chipS").textContent=m[1];$("sync").textContent=S.sync_text;
  const cashN=S.queue.filter(o=>o.status==="cash_wait").length;$("bdCash").textContent=cashN;$("bdCash").classList.toggle("hidden",!cashN);
  $("waDot").className="dot "+(S.wa.state==="ready"?"ok":S.wa.state==="qr"||S.wa.installing?"warn":"bad");
  notifyNew();                                   /* sound + alerts always run; only the visible tab is drawn */
  if(tab==="queue")renderQueue();else if(tab==="wa")renderWa();else if(tab==="rules")renderRules()}
let active=true,tick=null,busy=false;
async function refresh(){if(!A()||busy)return;busy=true;try{S=await A().get_state();render();
  if(firstState){firstState=false;if(S.open_counter&&S.has_key)showTab("counter");if(!S.has_key){$("bSettings").click();toast("Enter your Agent key to start")}}}catch(e){}busy=false}
function schedule(){clearInterval(tick);tick=active?setInterval(refresh,2000):null}
window.__setActive=function(on){active=!!on;document.documentElement.classList.toggle("paused",!active);if(active)refresh();schedule()};   /* called by the app when the window is hidden / shown */
document.addEventListener("visibilitychange",()=>window.__setActive(!document.hidden));
function boot(){refresh();schedule()}
if(window.pywebview&&window.pywebview.api)boot();else window.addEventListener("pywebviewready",boot);
</script></body></html>
'''


_MUTEX = []


def single_instance():
    """Only one Print Agent per Windows session (two copies would print every job twice)."""
    if not IS_WIN:
        return True
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.CreateMutexW(None, False, "Local\\RajeshPrintAgent_SingleInstance")
        if k.GetLastError() == 183:                       # ERROR_ALREADY_EXISTS
            return False
        _MUTEX.append(h)
    except Exception:
        pass
    return True


SHOW_FLAG = os.path.join(CONFIG_DIR, "show.flag")


class Tray:
    """Notification-area icon (needs 'pystray' + 'pillow'). If they are missing, ok stays False and the X button simply quits like before.
    `h` is a dict of callables supplied by run_webview_gui: open, quit, agent_online, wa_connected, auto_get/auto_set, mode_get/mode_set,
    sound_get/sound_set, restart_wa, open_web, startup_get/startup_set."""
    def __init__(self, h):
        self.ok = False; self.icon = None
        try:
            import pystray
            from PIL import Image, ImageDraw
        except Exception:
            return
        img = None
        try:
            if icon_path(): img = Image.open(icon_path()).convert("RGBA")
        except Exception:
            img = None
        if img is None:                                    # fallback if assets/printer.ico is missing
            img = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
            d.rounded_rectangle((2, 2, 62, 62), radius=14, fill=(124, 58, 237, 255))
            d.rectangle((20, 12, 44, 26), fill=(255, 255, 255, 255))
            d.rounded_rectangle((11, 24, 53, 44), radius=5, fill=(255, 255, 255, 255))
            d.rectangle((20, 38, 44, 54), fill=(224, 231, 255, 255), outline=(99, 102, 241, 255))
        M, I, SEP = pystray.MenuItem, pystray, pystray.Menu.SEPARATOR
        bg = lambda fn: (lambda icon, item: threading.Thread(target=fn, daemon=True).start())     # never block the tray thread (network calls)
        menu = pystray.Menu(
            M("Open Agent", lambda icon, item: h["open"](), default=True),
            M(lambda item: "● Agent Online" if h["agent_online"]() else "● Agent Offline", None, enabled=False),
            M(lambda item: "● WhatsApp Connected" if h["wa_connected"]() else "● WhatsApp Disconnected", None, enabled=False),
            SEP,
            M("Auto-Print Paid Orders (UPI)", bg(lambda: h["auto_set"](not h["auto_get"]())), checked=lambda item: bool(h["auto_get"]())),
            M("WhatsApp Bot Mode", pystray.Menu(
                M("Ask B&&W / Color", bg(lambda: h["mode_set"]("ask")), checked=lambda item: h["mode_get"]() != "instant", radio=True),
                M("Instant B&&W", bg(lambda: h["mode_set"]("instant")), checked=lambda item: h["mode_get"]() == "instant", radio=True))),
            M("Sound Alerts", bg(lambda: h["sound_set"](not h["sound_get"]())), checked=lambda item: bool(h["sound_get"]())),
            SEP,
            M("Restart WhatsApp Bot", bg(h["restart_wa"])),
            M("Open Counter Web (therajesh.shop)", bg(h["open_web"])),
            M("Start with Windows (Auto-Startup)", bg(lambda: h["startup_set"](not h["startup_get"]())), checked=lambda item: bool(h["startup_get"]())),
            SEP,
            M("Quit Agent Completely", lambda icon, item: h["quit"]()))
        self.icon = pystray.Icon("Agent", img, "Agent", menu)
        self.ok = True

    def start(self):
        try: self.icon.run_detached()
        except Exception: self.ok = False

    def refresh(self):
        try:
            if self.ok: self.icon.update_menu()
        except Exception:
            pass

    def notify(self, msg, title="Agent"):
        try:
            if self.ok: self.icon.notify(msg, title)
        except Exception:
            pass

    def stop(self):
        try:
            if self.icon: self.icon.stop()
        except Exception:
            pass


def run_webview_gui():
    global PHOTO_FIT, PROXY_PORT
    set_app_user_model_id()                                # before any window is created
    if not single_instance():                              # already running (maybe hidden in the tray): ask it to show its window, then leave
        try:
            os.makedirs(CONFIG_DIR, exist_ok=True); open(SHOW_FLAG, "w").close()
        except Exception:
            pass
        return
    if IS_WIN:                                             # lighter WebView2 (the window's Chromium): fewer processes, less memory
        os.environ.setdefault("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS",
                              "--disable-gpu-compositing --disable-extensions --renderer-process-limit=2 --disable-background-networking --disable-features=Translate --js-flags=--max-old-space-size=192")
    import webview
    cfg = load_cfg()
    cfg["auto"] = True          # the website decides what is approved (UPI-paid / cash-approved); this app prints every approved job
    cfg["poll"] = max(5.0, float(cfg.get("poll", 5) or 5))
    PHOTO_FIT = cfg.get("photo_fit") or PHOTO_FIT
    PRINT_OPTS.update({k: cfg.get(k, "") for k in ("paper_bw", "paper_color", "bin_bw", "bin_color", "copies_mode")})
    st = WebState(); agent = Agent(cfg, st); wa = WaBridge(cfg, st); mirror = Mirror(cfg)
    api = Api(cfg, agent, st, wa, mirror); st.on_printers = api._on_printers
    try: _srv, PROXY_PORT = start_counter_proxy(cfg)
    except Exception as e: st.log(f"Counter bridge could not start ({e}); using the direct page.")
    if not cfg["key"]: st.log("Enter your Agent key (same as AGENT_KEY in Cloudflare) in Settings.")

    quitting = [False]; win = [None]; shown = [True]

    def set_active(on):                                    # window visible -> normal speed; hidden/minimized -> slow polling, no UI refresh
        shown[0] = bool(on); agent.idle = mirror.idle = not on
        def js():                                          # evaluate_js waits for the page: never do that on the GUI / event thread
            try: win[0].evaluate_js("window.__setActive(%s)" % ("true" if on else "false"))
            except Exception: pass
        threading.Thread(target=js, daemon=True).start()
        if on: mirror.wake.set()

    def show_window():
        def go():
            try: win[0].show(); win[0].restore()
            except Exception: pass
            set_active(True)
        threading.Thread(target=go, daemon=True).start()

    def hide_window():                                     # returns immediately; the real work happens on a daemon thread
        def go():
            try: win[0].hide()
            except Exception: pass
            set_active(False)
        threading.Thread(target=go, daemon=True).start()

    def quit_all():                                        # returns at once: nothing here can freeze the tray menu or the window
        if quitting[0]: return
        quitting[0] = True
        threading.Timer(20, os._exit, args=(0,)).start()   # safety net: never leave a zombie process

        def work():
            try: win[0].hide()                             # the window disappears instantly
            except Exception: pass
            try: tray.stop()
            except Exception: pass
            agent.stop.set(); agent.wake.set(); agent.pwake.set(); mirror.stop.set(); mirror.wake.set()
            try: wa.stop()                                 # taskkill /F /T on the bot + Chrome, then sweep leftovers and lock files
            except Exception: pass
            try: wa.kill_orphans(); wa.clear_locks()
            except Exception: pass
            d = threading.Thread(target=lambda: win[0].destroy(), daemon=True); d.start(); d.join(1.5)
            os._exit(0)
        threading.Thread(target=work, daemon=True).start()

    def status_text():
        if agent.paused: return "Agent Status: Paused"
        if st.conn == "badkey": return "Agent Status: Wrong agent key"
        if st.conn == "offline": return "Agent Status: Offline (check internet)"
        if wa.state == "ready": return "Agent Status: Online (Auto-Print & WhatsApp Active)"
        return "Agent Status: Online (Auto-Print Active · WhatsApp: %s)" % (wa.state or "off")

    def agent_online():
        return not agent.paused and st.conn not in ("badkey", "offline")

    def wa_connected():
        return wa.state == "ready"

    def restart_wa():
        pr = wa.problem()
        if pr:
            tray.notify("WhatsApp bot cannot start (%s). Open Agent to fix it." % pr); return
        tray.notify("Restarting WhatsApp bot…")
        wa.reconnect(); tray.refresh()

    def startup_set(on):
        cfg["startup"] = bool(on); save_cfg(cfg)
        try: apply_startup(cfg, st.log)
        except Exception as e: st.log(f"Start-with-Windows failed: {e}")
        tray.refresh()

    def after(fn):                                         # run a setter, then redraw the tray menu
        def go(*a):
            fn(*a); tray.refresh()
        return go

    tray = Tray({
        "open": show_window, "quit": quit_all, "agent_online": agent_online, "wa_connected": wa_connected,
        "auto_get": lambda: (mirror.flags or {}).get("autoprint") is not False, "auto_set": after(lambda v: api.set_flag("autoprint", bool(v))),
        "mode_get": lambda: (mirror.flags or {}).get("wabot") or "ask", "mode_set": after(lambda v: api.set_flag("wabot", v)),
        "sound_get": lambda: bool(cfg.get("sound", True)), "sound_set": after(lambda v: api.set_pref("sound", bool(v))),
        "restart_wa": restart_wa, "open_web": lambda: __import__("webbrowser").open("https://therajesh.shop"),
        "startup_get": lambda: bool(cfg.get("startup", True)), "startup_set": startup_set})
    api._on_quit = quit_all
    background = "--background" in sys.argv and tray.ok     # started by Windows at boot: go straight to the tray (never hide if there is no tray icon to bring it back)
    shown[0] = not background; agent.idle = mirror.idle = background

    def on_cash(new):                                      # a customer chose cash while the window is hidden: tell the owner
        if shown[0]: return
        o = new[0]
        tray.notify(f"💵 Cash Pending: ₹{o.get('amount')} · Token #{o.get('token') or o.get('id')}" + (f" (+{len(new) - 1} more)" if len(new) > 1 else ""))
        if cfg.get("sound", True) and IS_WIN:
            try: import winsound; winsound.MessageBeep()
            except Exception: pass
    mirror.on_cash = on_cash; mirror.on_approved = agent.wake.set

    win[0] = webview.create_window(APP_NAME, html=UI_HTML.replace("%%LOGO_SVG%%", LOGO_SVG), js_api=api, width=1320, height=880, min_size=(1000, 660), background_color="#eef2ff", hidden=background)

    def on_closing():                                      # the X button: keep running in the tray instead of quitting
        if quitting[0] or not tray.ok:
            return True
        hide_window()                                      # only spawns a thread
        if not cfg.get("tray_hint"):
            def hint():                                    # first-time balloon + config write: off the close event
                cfg["tray_hint"] = True; save_cfg(cfg)
                tray.notify("Agent is still running in the background. Click the tray icon to reopen.")
            t = threading.Timer(0.2, hint); t.daemon = True; t.start()
        return False                                       # cancel the close; nothing blocking happened above
    try:
        win[0].events.closing += on_closing
        win[0].events.loaded += lambda: set_active(shown[0])
        win[0].events.minimized += lambda: set_active(False)
        win[0].events.restored += lambda: set_active(True)
    except Exception:
        pass

    try: win[0].events.shown += lambda: threading.Thread(target=apply_window_icon, daemon=True).start()
    except Exception: pass
    tray.start()
    threading.Thread(target=apply_window_icon, daemon=True).start()          # also covers a window that starts hidden in the tray
    threading.Thread(target=agent.printers_loop, daemon=True).start()
    threading.Thread(target=agent.loop, daemon=True).start()
    threading.Thread(target=mirror.loop, daemon=True).start()

    def boot_tasks():                                      # everything heavy runs off the UI thread
        if not cfg.get("startup_init"):                    # first launch after this update: Windows auto-startup ON by default
            cfg["startup_init"] = True; cfg["startup"] = True; save_cfg(cfg)
            try: apply_startup(cfg, st.log)
            except Exception as e: st.log(f"Auto-startup could not be set: {e}")
        if background: time.sleep(10)                      # let Windows finish booting before starting the WhatsApp browser
        if cfg.get("wa_auto", True) and wa.problem() is None:
            wa.start()
    threading.Thread(target=boot_tasks, daemon=True).start()

    def flag_watch():                                      # a second launch asks this copy to show itself
        while not quitting[0]:
            try:
                if os.path.exists(SHOW_FLAG):
                    os.remove(SHOW_FLAG); show_window()
            except Exception:
                pass
            time.sleep(2)
    threading.Thread(target=flag_watch, daemon=True).start()

    import atexit
    atexit.register(lambda: (wa.kill_orphans(), wa.clear_locks()))     # last line of defence: never leave a bot / Chrome behind
    try:
        webview.start(private_mode=False, storage_path=os.path.join(CONFIG_DIR, "webview"))
    finally:
        agent.stop.set(); agent.wake.set(); agent.pwake.set(); mirror.stop.set(); mirror.wake.set(); tray.stop()
        try: wa.stop()
        except Exception: pass


if __name__ == "__main__":
    set_app_user_model_id()
    if "--install-startup" in sys.argv:                 # used by BUILD_EXE.bat: only switch on "start with Windows", do not open the window
        _c = load_cfg(); _c["startup"] = True; save_cfg(_c)
        try: apply_startup(_c, print)
        except Exception as _e: print("Could not set start-with-Windows:", _e)
        sys.exit(0)
    if "--counter" in sys.argv:
        run_counter()
    else:
        use_web = os.environ.get("RPA_GUI") != "tk"
        if use_web:
            try:
                import webview  # noqa: F401   (pip install pywebview)
            except ImportError:
                use_web = False
        if use_web:
            try:
                run_webview_gui()
                sys.exit(0)
            except SystemExit:
                raise
            except Exception as e:                       # e.g. WebView2 missing -> fall back to the classic window
                try:
                    os.makedirs(CONFIG_DIR, exist_ok=True)
                    open(os.path.join(CONFIG_DIR, "webview_error.txt"), "w").write(repr(e))
                except Exception:
                    pass
        run_gui()
