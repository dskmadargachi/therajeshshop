#!/usr/bin/env python3
"""
Passport photo maker for the print agent (WhatsApp option 3).

    photo (jpg/png)  ->  background removed  ->  face-centred 35x45 mm crop  ->  thin border
                     ->  4x6 inch sheet(s) at 300 DPI, up to 8 photos per sheet

Background removal, in this order:
  1. `rembg`             (local, free; first use downloads its ~170 MB model)  - pip install rembg onnxruntime
  2. remove.bg API       when REMOVEBG_API_KEY is set (config.env / environment)
  3. none                the original background is kept and a warning is logged (printing still works)
When the agent runs as a PyInstaller .exe, rembg is used through a system Python (`py -3`) that has it - see ensure_rembg().

Command line (also used by the agent for step 1 from the .exe):
    python passport_sheet.py --rembg-filter < in.jpg > out.png
    python passport_sheet.py photo.jpg 6 outdir [--bg white|blue]
"""
import io, os, subprocess, sys, shutil, json, urllib.request, uuid

DPI = 300
PHOTO_W, PHOTO_H = 413, 531                  # 35 x 45 mm at 300 DPI (Indian passport size)
SHEET_W, SHEET_H = 1800, 1200                # 6 x 4 in landscape; the photo printer path turns it onto 4x6 portrait paper
PER_SHEET = 8                                # 4 columns x 2 rows
GAP = 24                                     # cutting gap between photos (px)
BORDER = 2                                   # thin border around every photo (px)
BG = {"white": (255, 255, 255), "blue": (214, 232, 250)}


def _noop(*a, **k):
    pass


# ----------------------------------------------------------------------------- background removal
def _cflags():
    return 0x08000000 if os.name == "nt" else 0          # CREATE_NO_WINDOW


def _system_python():
    """A real Python interpreter (not the frozen .exe) that can run `-m pip` / rembg."""
    if not getattr(sys, "frozen", False):
        return sys.executable
    for cmd in (["py", "-3"], ["python"], ["python3"]):
        exe = shutil.which(cmd[0])
        if exe:
            try:
                r = subprocess.run(cmd + ["-c", "import sys;print(sys.version_info[0])"], capture_output=True, text=True, timeout=20, creationflags=_cflags())
                if r.stdout.strip() == "3":
                    return cmd
            except Exception:
                pass
    return None


def _py_cmd(py):
    return list(py) if isinstance(py, (list, tuple)) else [py]


def ensure_rembg(log=_noop, install=True):
    """-> 'inproc' | ('ext', python_cmd) | None.  Installs rembg once (needs internet) when it is missing."""
    try:
        import rembg  # noqa: F401
        return "inproc"
    except Exception:
        pass
    py = _system_python()
    if not py:
        return None

    def has():
        try:
            r = subprocess.run(_py_cmd(py) + ["-c", "import rembg, onnxruntime"], capture_output=True, timeout=60, creationflags=_cflags())
            return r.returncode == 0
        except Exception:
            return False
    if has():
        return ("ext", py) if getattr(sys, "frozen", False) else "inproc"
    if install:
        log("   installing rembg (one time, needs internet, a few minutes)...")
        try:
            r = subprocess.run(_py_cmd(py) + ["-m", "pip", "install", "--upgrade", "rembg", "onnxruntime", "pillow"], capture_output=True, text=True, timeout=1500, creationflags=_cflags())
            if r.returncode != 0:
                log("   rembg install failed: " + (r.stderr or r.stdout).strip()[-200:])
        except Exception as e:
            log(f"   rembg install failed: {e}")
        if has():
            if getattr(sys, "frozen", False):
                return ("ext", py)
            try:
                import importlib; importlib.invalidate_caches(); import rembg  # noqa: F401
                return "inproc"
            except Exception:
                return None
    return None


def _removebg_api(png_bytes, key):
    boundary = uuid.uuid4().hex
    body = io.BytesIO()
    for name, val in (("size", "auto"), ("format", "png")):
        body.write(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{val}\r\n'.encode())
    body.write(f'--{boundary}\r\nContent-Disposition: form-data; name="image_file"; filename="photo.png"\r\nContent-Type: image/png\r\n\r\n'.encode())
    body.write(png_bytes); body.write(f"\r\n--{boundary}--\r\n".encode())
    req = urllib.request.Request("https://api.remove.bg/v1.0/removebg", data=body.getvalue(), method="POST",
                                 headers={"X-Api-Key": key, "Content-Type": "multipart/form-data; boundary=" + boundary})
    with urllib.request.urlopen(req, timeout=90) as r:
        return r.read()


def remove_background(img, log=_noop, removebg_key=""):
    """-> (RGBA image with transparent background, method) ; method 'none' when nothing worked (the original photo is returned)."""
    from PIL import Image
    src = img.convert("RGB")
    buf = io.BytesIO(); src.save(buf, "PNG"); raw = buf.getvalue()
    mode = ensure_rembg(log)
    try:
        if mode == "inproc":
            from rembg import remove
            return Image.open(io.BytesIO(remove(raw))).convert("RGBA"), "rembg"
        if isinstance(mode, tuple):
            me = os.path.abspath(__file__) if os.path.exists(os.path.abspath(__file__)) else os.path.join(getattr(sys, "_MEIPASS", ""), "passport_sheet.py")
            r = subprocess.run(_py_cmd(mode[1]) + [me, "--rembg-filter"], input=raw, capture_output=True, timeout=600, creationflags=_cflags())
            if r.returncode == 0 and r.stdout:
                return Image.open(io.BytesIO(r.stdout)).convert("RGBA"), "rembg"
            log("   rembg (external python) failed: " + r.stderr.decode("utf-8", "replace").strip()[-160:])
    except Exception as e:
        log(f"   rembg failed: {e}")
    key = removebg_key or os.environ.get("REMOVEBG_API_KEY", "")
    if key:
        try:
            return Image.open(io.BytesIO(_removebg_api(raw, key))).convert("RGBA"), "remove.bg"
        except Exception as e:
            log(f"   remove.bg failed: {e}")
    log("   WARNING: no background remover available (pip install rembg onnxruntime, or set REMOVEBG_API_KEY) - original background kept")
    return src.convert("RGBA"), "none"


# ----------------------------------------------------------------------------- face / subject centring
def _face_box(rgb):
    """(x, y, w, h) of the biggest face with OpenCV when it is installed, else None."""
    try:
        import cv2, numpy as np
        g = cv2.cvtColor(np.array(rgb), cv2.COLOR_RGB2GRAY)
        c = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        f = c.detectMultiScale(g, 1.1, 5, minSize=(max(40, g.shape[1] // 12),) * 2)
        if len(f):
            return tuple(int(v) for v in max(f, key=lambda b: b[2] * b[3]))
    except Exception:
        pass
    return None


def _subject_head(alpha):
    """From the transparency mask: (cx, head_top, head_h) of the person's head, or None."""
    bbox = alpha.point(lambda v: 255 if v > 40 else 0).getbbox()
    if not bbox:
        return None
    x0, y0, x1, y1 = bbox
    hh = y1 - y0
    band = alpha.crop((x0, y0 + int(hh * 0.04), x1, y0 + int(hh * 0.22))).point(lambda v: 255 if v > 40 else 0).getbbox()   # head rows (above the shoulders)
    if band:
        bx0, _, bx1, _ = band
        head_w = bx1 - bx0
        cx = x0 + (bx0 + bx1) / 2
    else:
        head_w, cx = (x1 - x0) * 0.5, (x0 + x1) / 2
    head_h = min(head_w * 1.38, hh)
    return cx, y0, head_h


def smart_crop(rgba, bg_rgb):
    """Crops to 35:45 with the head about 72% of the height, centred; pads with the background colour where the photo is too tight."""
    from PIL import Image
    W, H = rgba.size
    ratio = PHOTO_W / PHOTO_H
    face = _face_box(rgba.convert("RGB"))
    head = _subject_head(rgba.split()[3]) if rgba.getextrema()[3][0] < 250 else None   # a real mask exists only after background removal
    if face:
        fx, fy, fw, fh = face
        cx, head_top, head_h = fx + fw / 2, fy - 0.22 * fh, 1.30 * fh
    elif head:
        cx, head_top, head_h = head
    else:                                                                              # nothing to go on: centred, a little above the middle
        ch = min(H, W / ratio); cw = ch * ratio
        cx, head_top, head_h = W / 2, max(0.0, (H - ch) / 2 + 0.06 * ch), 0.72 * ch
    ch = head_h / 0.72
    cw = ch * ratio
    top = head_top - 0.10 * ch
    left = cx - cw / 2
    canvas = Image.new("RGB", (W, H), bg_rgb); canvas.paste(rgba, (0, 0), rgba)        # solid background first
    pad = int(max(cw, ch))
    big = Image.new("RGB", (W + 2 * pad, H + 2 * pad), bg_rgb); big.paste(canvas, (pad, pad))
    box = (int(round(left)) + pad, int(round(top)) + pad, int(round(left + cw)) + pad, int(round(top + ch)) + pad)
    return big.crop(box).resize((PHOTO_W, PHOTO_H), Image.LANCZOS)


# ----------------------------------------------------------------------------- sheets
def _frame(photo):
    from PIL import ImageDraw
    p = photo.copy(); d = ImageDraw.Draw(p)
    d.rectangle((0, 0, PHOTO_W - 1, PHOTO_H - 1), outline=(190, 190, 190), width=BORDER)   # thin clean border = cutting guide
    return p


def split_counts(n):
    """12 photos -> [6, 6] (even sheets), 8 -> [8], 6 -> [6], 20 -> [7, 7, 6]."""
    n = max(1, int(n)); sheets = -(-n // PER_SHEET); base, extra = divmod(n, sheets)
    return [base + (1 if i < extra else 0) for i in range(sheets)]


def make_sheets(photo, counts, outdir):
    from PIL import Image
    cols, rows = 4, 2
    gw = cols * PHOTO_W + (cols - 1) * GAP; gh = rows * PHOTO_H + (rows - 1) * GAP
    ox, oy = (SHEET_W - gw) // 2, (SHEET_H - gh) // 2
    one = _frame(photo); paths = []
    for si, n in enumerate(counts, 1):
        sheet = Image.new("RGB", (SHEET_W, SHEET_H), (255, 255, 255))
        for k in range(n):
            r, c = divmod(k, cols)
            sheet.paste(one, (ox + c * (PHOTO_W + GAP), oy + r * (PHOTO_H + GAP)))
        p = os.path.join(outdir, f"passport_sheet_{si}.png")
        sheet.save(p, "PNG", dpi=(DPI, DPI)); paths.append(p)
    return paths


def build_passport_sheets(src_path, copies, outdir, bg="white", log=_noop, removebg_key=""):
    """-> list of sheet PNG paths (each 1800x1200 @300 DPI = 6x4 in), `copies` photos in total."""
    from PIL import Image, ImageOps
    os.makedirs(outdir, exist_ok=True)
    img = ImageOps.exif_transpose(Image.open(src_path))
    if max(img.size) > 3000:                                   # keep rembg fast
        img.thumbnail((3000, 3000))
    rgba, method = remove_background(img, log, removebg_key)
    photo = smart_crop(rgba, BG.get(bg, BG["white"]))
    log(f"   passport photo ready (background: {method}); {copies} photo(s) on {len(split_counts(copies))} sheet(s)")
    return make_sheets(photo, split_counts(copies), outdir)


if __name__ == "__main__":
    if "--rembg-filter" in sys.argv:                          # stdin: image bytes -> stdout: PNG with transparent background
        from rembg import remove
        sys.stdout.buffer.write(remove(sys.stdin.buffer.read()))
    elif len(sys.argv) >= 4:
        bgc = sys.argv[sys.argv.index("--bg") + 1] if "--bg" in sys.argv else "white"
        print(json.dumps(build_passport_sheets(sys.argv[1], int(sys.argv[2]), sys.argv[3], bgc, print)))
    else:
        print(__doc__)
