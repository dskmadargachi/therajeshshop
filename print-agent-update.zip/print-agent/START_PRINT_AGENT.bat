@echo off
cd /d "%~dp0"
py -c "import webview, pystray, PIL" 2>nul || py -m pip install --quiet pywebview pystray pillow
start "" pyw printer_agent_gui.py
